package turizam;

import smestaj.*;

import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.io.*;

public class Hotel {
	
	LinkedList<SmestajnaJedinica> smestaj = new LinkedList<SmestajnaJedinica>();

	public Hotel(int brojJedinica){
		//Prvu cetvrtinu popunjavamo dvokrevetnim sobama
		for(int i=1;i<=brojJedinica/4;i++){
			Soba s = new Soba();
			s.setBrojKreveta(2);
			s.setDatumOslobadjanja(new GregorianCalendar());
			
			smestaj.add(s);
		}
		
		//Drugu cetvrtinu popunjavamo trokrevetnim sobama
		for(int i=1;i<=brojJedinica/4;i++){
			Soba s = new Soba();
			s.setBrojKreveta(3);
			s.setDatumOslobadjanja(new GregorianCalendar());
			
			smestaj.addLast(s);
		}
		
		//Preostalu polovinu popunjavamo cetvorokrevetnim apartmanima
		for(int i=1;i<=brojJedinica/2;i++){
			Apartman a = new Apartman();
			a.setBrojKreveta(4);
			a.setDatumOslobadjanja(new GregorianCalendar());
			
			smestaj.addLast(a);
		}
	}
	
	public void istampajSmestaj(boolean imaKuhinju){
		try{
			PrintWriter out = new PrintWriter(new FileWriter("soba.out"));
			
			for (int i = 0; i < smestaj.size(); i++)
				if (smestaj.get(i).imaKuhinju()==imaKuhinju)
					out.println(smestaj.get(i));
			
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void rezervisiSmestaj(int brojKreveta, GregorianCalendar datum, char tip) throws Exception{
		//Prolazi se kroz listu smestaja i traze se oni koji odgovaraju po broju
		//kreveta i datumu oslobadjanja. Onda se proverava da li je tip odgovarajuci
		//i ako jeste, datum oslobadjanja se postavlja na trenutni i izlazi se iz metode.
		for (int i = 0; i < smestaj.size(); i++)
			if (smestaj.get(i).getDatumOslobadjanja().before(new GregorianCalendar()) &&
					smestaj.get(i).getBrojKreveta()==brojKreveta &&
					((tip=='A' && smestaj.get(i) instanceof Apartman)||
					(tip=='S' && smestaj.get(i) instanceof Soba))){
				smestaj.get(i).setDatumOslobadjanja(datum);
				return;
			}
		
		//Ako nije pronadjen nijedan odgovarajuci smestaj, metoda baca izuzetak
		throw new Exception("Nije pronadjen trazeni smestaj");
	}
	
	
}
