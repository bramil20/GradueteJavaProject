package smestaj;

public class Soba extends SmestajnaJedinica {

	public boolean imaKuhinju() {
		return false;
	}

	public String toString() {
		return "Obicna soba [datum oslobadjanja=" + getDatumOslobadjanja()
				+ ", broj kreveta=" + getBrojKreveta() + "]";
	}
	
	

}
