package smestaj;

import java.util.GregorianCalendar;

public abstract class SmestajnaJedinica {

	private GregorianCalendar datumOslobadjanja;
	private int brojKreveta;
	
	public GregorianCalendar getDatumOslobadjanja() {
		return datumOslobadjanja;
	}
	
	public void setDatumOslobadjanja(GregorianCalendar datumOslobadjanja) {
		if (datumOslobadjanja==null)
			throw new RuntimeException("Morate uneti datum oslobadjanja");
		
		this.datumOslobadjanja = datumOslobadjanja;
	}
	
	public int getBrojKreveta() {
		return brojKreveta;
	}
	
	public void setBrojKreveta(int brojKreveta) {
		if (brojKreveta<1)
			throw new RuntimeException("Broj kreveta mora biti 1 ili vise");
		
		this.brojKreveta = brojKreveta;
	}
	
	public abstract boolean imaKuhinju();
}
