package smestaj;

public class Apartman extends SmestajnaJedinica {

	public boolean imaKuhinju() {
		return true;
	}
	
	public String toString() {
		return "Apartman [datum oslobadjanja=" + getDatumOslobadjanja()
				+ ", broj kreveta=" + getBrojKreveta() + "]";
	}

}
