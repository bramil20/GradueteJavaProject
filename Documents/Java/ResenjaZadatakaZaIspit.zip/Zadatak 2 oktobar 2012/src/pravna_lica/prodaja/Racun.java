package pravna_lica.prodaja;

import java.util.GregorianCalendar;

import pravna_lica.Preduzece;

public class Racun {
	
	private GregorianCalendar datum;
	private double iznos;
	private Preduzece preduzece;
	
	public GregorianCalendar getDatum() {
		return datum;
	}
	
	public void setDatum(GregorianCalendar datum) {
		if (datum==null)
			throw new RuntimeException("Morate uneti datum");

		this.datum = datum;
	}
	
	public double getIznos() {
		return iznos;
	}
	
	public void setIznos(double iznos) {
		if (iznos<=0)
			throw new RuntimeException("Iznos mora biti veci od nule");
		
		this.iznos = iznos;
	}
	
	public Preduzece getPreduzece() {
		return preduzece;
	}
	
	public void setPreduzece(Preduzece preduzece) {
		if (preduzece==null)
			throw new RuntimeException("Morate uneti preduzece");

		this.preduzece = preduzece;
	}
	

}
