package pravna_lica.prodaja;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import pravna_lica.Preduzece;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.GregorianCalendar;

public class ProdajaNaVelikoGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	
	private Racun[] racuni;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProdajaNaVelikoGUI frame = new ProdajaNaVelikoGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProdajaNaVelikoGUI() {
		//Inicijalizacija niza se obavlja tj dodaje u okviru ovog konstruktora
		racuni = new Racun[100];
		
		setTitle("Prodaja na veliko");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 364, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPib = new JLabel("PIB");
		lblPib.setBounds(12, 12, 70, 15);
		contentPane.add(lblPib);
		
		JLabel lblNaziv = new JLabel("Naziv");
		lblNaziv.setBounds(12, 68, 70, 15);
		contentPane.add(lblNaziv);
		
		JLabel lblAdresa = new JLabel("Adresa");
		lblAdresa.setBounds(12, 125, 70, 15);
		contentPane.add(lblAdresa);
		
		JLabel lblTelefon = new JLabel("Telefon");
		lblTelefon.setBounds(12, 183, 70, 15);
		contentPane.add(lblTelefon);
		
		JLabel lblIznos = new JLabel("Iznos");
		lblIznos.setBounds(12, 239, 70, 15);
		contentPane.add(lblIznos);
		
		textField = new JTextField();
		textField.setBounds(12, 37, 114, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setText("");
		textField_1.setBounds(12, 94, 114, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(12, 152, 114, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setText("");
		textField_3.setBounds(12, 210, 114, 19);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(12, 264, 114, 19);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnDodaj = new JButton("Dodaj");
		btnDodaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Preuzimanje podataka iz odgovarajucih polja za unos i popunjavanje novog preduzeca
				Preduzece p = new Preduzece();
				p.setPIB(Integer.parseInt(textField.getText()));
				p.setNaziv(textField_1.getText());
				p.setAdresa(textField_2.getText());
				p.setTelefon(Integer.parseInt(textField_3.getText()));
				
				//Preuzimanje iznosa i popunjavanje novog racuna
				Racun r = new Racun();
				r.setIznos(Double.parseDouble(textField_4.getText()));
				r.setDatum(new GregorianCalendar());
				r.setPreduzece(p);
				
				//Unos u niz.
				for (int i=0;i<racuni.length;i++)
					if (racuni[i]==null){
						racuni[i]=r;
						return;
					}
				
				//Ako nije unet u niz baca se izuzetak
				throw new RuntimeException("U nizu nema mesta");
			}
		});
		btnDodaj.setBounds(202, 34, 117, 25);
		contentPane.add(btnDodaj);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Preuzimanje unetog PIB-a iz polja za unos i pretvaranje u ceo broj
				int unetiPIB = Integer.parseInt(textField.getText());
				
				//Prolazi se kroz niz i brisu se racuni u kojima je pib preduzeca
				//jednak unetom.
				for (int i=0;i<racuni.length;i++)
					if(racuni[i].getPreduzece().getPIB()==unetiPIB)
						racuni[i]=null;
				
				//Na kraju se obrisu sva polja za unos
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
			}
		});
		btnObrisi.setBounds(202, 94, 117, 25);
		contentPane.add(btnObrisi);
		
		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("racuni.out")));
					
					for (int i=0;i<racuni.length;i++)
						if(racuni[i]!=null){
							out.writeInt(racuni[i].getDatum().get(GregorianCalendar.DAY_OF_MONTH));
							out.writeChar('\t');
							out.writeInt(racuni[i].getDatum().get(GregorianCalendar.MONTH));
							out.writeChar('\t');
							out.writeInt(racuni[i].getDatum().get(GregorianCalendar.YEAR));
							out.writeChar('\t');
							out.writeInt(racuni[i].getPreduzece().getPIB());
							out.writeChar('\t');
							out.writeUTF(racuni[i].getPreduzece().getNaziv());
							out.writeChar('\t');
							out.writeUTF(racuni[i].getPreduzece().getAdresa());
							out.writeChar('\t');
							out.writeInt(racuni[i].getPreduzece().getTelefon());
							out.writeChar('\t');
							out.writeDouble(racuni[i].getIznos());
						}
					
					out.close();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
				
			}
		});
		btnSacuvaj.setBounds(202, 149, 117, 25);
		contentPane.add(btnSacuvaj);
	}
}
