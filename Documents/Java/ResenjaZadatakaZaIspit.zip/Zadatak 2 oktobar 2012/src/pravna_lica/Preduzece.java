package pravna_lica;

public class Preduzece {
	
	private int PIB;
	private String naziv;
	private int telefon;
	private String adresa;
	
	public int getPIB() {
		return PIB;
	}
	
	public void setPIB(int pIB) {
		if (pIB<0)
			throw new RuntimeException("PIB mora biti veci od nule");
			
		PIB = pIB;
	}
	
	public String getNaziv() {
		return naziv;
	}
	
	public void setNaziv(String naziv) {
		if (naziv==null || naziv.equals(""))
			throw new RuntimeException("Naziv ne sme biti null niti prazan String");
		
		this.naziv = naziv;
	}
	
	public int getTelefon() {
		return telefon;
	}
	
	public void setTelefon(int telefon) {
		this.telefon = telefon;
	}
	
	public String getAdresa() {
		return adresa;
	}
	
	public void setAdresa(String adresa) {
		if (adresa==null || adresa.equals(""))
			throw new RuntimeException("Adresa ne sme biti null niti prazan String");
			
		this.adresa = adresa;
	}
	
	

}
