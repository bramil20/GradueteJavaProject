package porodiliste.statistika;

public interface Statistike {
	
	public void upisiEkstreme(String naziv);
	
	public int[] vratiFrekvencijskuTabelu();

}
