package klijenti.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Dimension;
import java.util.LinkedList;

import klijenti.domen.Klijent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.DataInputStream;

import java.io.*;

public class KlijentiGUI extends JFrame {

	private JPanel contentPane;
	private JComboBox comboBox;
	private JTextArea textArea;
	private LinkedList<Klijent> vipKlijenti = new LinkedList<Klijent>();
	private LinkedList<Klijent> obicniKlijenti = new LinkedList<Klijent>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KlijentiGUI frame = new KlijentiGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public KlijentiGUI() {
		setResizable(false);
		setTitle("Klijenti");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		textArea = new JTextArea();
		contentPane.add(textArea, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(120, 10));
		contentPane.add(panel, BorderLayout.WEST);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"VIP", "Obicni"}));
		panel.add(comboBox);
		
		JButton btnPrikazi = new JButton("Prikazi");
		btnPrikazi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String izabranaStavka = (String)comboBox.getSelectedItem();
				
				if (izabranaStavka.equals("VIP")){
					textArea.setText("VIP klijenti");
					for(int i=0;i<vipKlijenti.size();i++)
						textArea.append("\n"+vipKlijenti.get(i));
					
				}
				else{
					textArea.setText("Obicni klijenti");
					for(int i=0;i<obicniKlijenti.size();i++)
						textArea.append("\n"+obicniKlijenti.get(i));
				}
				
			}
		});
		panel.add(btnPrikazi);
		
		JButton btnUcitaj = new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream("klijenti.dat")));
					
					while (in.available()!=0){
						//Pravi se novi klijent i popunjava podacima
						Klijent k = new Klijent();
						k.setIme(in.readUTF());
						in.readChar();
						k.setPrezime(in.readUTF());
						in.readChar();
						k.setTelefon(in.readUTF());
						in.readChar();
						//Ka kraju se ucitava i status
						String status = in.readUTF();
						in.readChar();
						
						//Ako je status "VIP" klijent se upisuje u listu VIP klijenata,
						//a inace u listu obicnih klijenata
						if(status.equals("VIP"))
							vipKlijenti.add(k);
						else
							obicniKlijenti.add(k);
					}
					
					in.close();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
		});
		panel.add(btnUcitaj);
		
		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					PrintWriter out = new PrintWriter(new FileWriter("klijenti.txt"));
					
					//Prva petlja tj njen brojac idu od 10 do 39 tj. kroz sve pozivne brojeve
					for (int i=10;i<=39;i++){
						//Za svaki pozivni broj se po jednom prodje kroz VIP listu i obicnu listu
						//i svaki klijent sa tim pozivnim brojem se upisuje u fajl
						for (int j = 0; j < vipKlijenti.size(); j++) 
							if (vipKlijenti.get(j).getTelefon().startsWith("0"+i))
								out.println(vipKlijenti.get(i));
						
						for (int j = 0; j < obicniKlijenti.size(); j++) 
							if (obicniKlijenti.get(j).getTelefon().startsWith("0"+i))
								out.println(obicniKlijenti.get(i));
					}
					
					out.close();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
		});
		panel.add(btnSacuvaj);
	}

}
