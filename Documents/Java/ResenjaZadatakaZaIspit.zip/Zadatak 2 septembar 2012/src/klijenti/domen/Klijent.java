package klijenti.domen;

public class Klijent {
	
	private String ime, prezime, telefon;

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		if(ime==null || ime.equals(""))
			throw new RuntimeException("Ime ne sme biti null niti prazan String");
		
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		if(prezime==null || prezime.equals(""))
			throw new RuntimeException("Prezime ne sme biti null niti prazan String");
		
		this.prezime = prezime;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		if(telefon==null || telefon.length()<8 || !telefon.startsWith("0"))
			throw new RuntimeException("Telefon mora imati makar osam znakova i mora pocinjati nulom");
		
		this.telefon = telefon;
	}

	public String toString() {
		return "Klijent [ime=" + ime + ", prezime=" + prezime + ", telefon="
				+ telefon + "]";
	}
	
}
