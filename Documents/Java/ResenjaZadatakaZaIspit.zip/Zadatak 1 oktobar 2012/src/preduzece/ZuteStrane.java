package preduzece;

import java.io.*;
import java.util.GregorianCalendar;
import java.util.LinkedList;

import preduzece.registar.RegistarPreduzeca;

public class ZuteStrane implements RegistarPreduzeca {

	private Preduzece[] imenik;
	
	public ZuteStrane(){
		imenik = new Preduzece[1000];
	}
	
	public ZuteStrane(int kapacitet){
		imenik = new Preduzece[kapacitet];
	}
	
	public ZuteStrane(String fajl){
		imenik = new Preduzece[1000];
		
		try{
			ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fajl)));
			//Ucitavaju se objekti dok ih ima u fajlu. Moze da ih ima maksimalno 1000
			//i to se onda poklapa sa duzinom niza. Ako ih bude manje, izuzetak koji
			//ce da bude bacen ce da prekine for petlju i zaustavi ucitavanje.
			try{
				for (int i = 0; i < imenik.length; i++) 
					imenik[i]=(Preduzece)(in.readObject());
			}catch(Exception e){}
			
			in.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public LinkedList<Preduzece> nadjiPreduzece(String deoNaziva) {
		//Pravi se nova prazna lista
		LinkedList<Preduzece> novaLista = new LinkedList<Preduzece>();
		
		try{
			PrintWriter out = new PrintWriter(new FileWriter("pronadjeno.txt"));
			
			//Prolazi se kroz imenik i pronalaze se preduzeca koja u nazivu imaju
			//uneti String. Kad se nadju, dodaju se u listu i upisuju u fajl.
			for (int i = 0; i < imenik.length; i++) 
				if (imenik[i]!=null && imenik[i].getNaziv().indexOf(deoNaziva)!=-1){
					novaLista.add(imenik[i]);
					out.println(imenik[i]);
				}
		
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		//Ako nova lista nije prazna tj ako je pronadjeno neko preduzece,
		//metoda vraca listu.
		if (novaLista.size()>0)
			return novaLista;
		
		//U suprotnom, metoda baca izuzetak 
		throw new RuntimeException("Nije pronadjeno nijedno preduzece");
	}

	public void dodajPreduzece(int PIB, String naziv,
			GregorianCalendar datumRegistracije, String telefon) {
		//Pravi se nov objekat klase Preduzece i puni unetim vrednostima.
		Preduzece p = new Preduzece();
		p.setNaziv(naziv);
		p.setPIB(PIB);
		p.setDatumRegistracije(datumRegistracije);
		p.setTelefon(telefon);
		
		//Uzima se trenutni datum i podesava se na isti dan i mesec ali 10 godina ranije.
		GregorianCalendar datum = new GregorianCalendar();
		datum.set(datum.get(GregorianCalendar.YEAR)-10, 
				datum.get(GregorianCalendar.MONTH),
				datum.get(GregorianCalendar.DAY_OF_MONTH));
		
		//Ako je datum registracije preduzeca pre ovog datuma od pre 10 godina,
		//preduzece se unosi u prvu polovinu niza i to na prvo slobodno mesto.
		//U suprotnom, preduzece se unosi u drugu polovinu niza na prvo slobodno
		//mesto.
		if (datumRegistracije.before(datum))
			for (int i = 0; i < imenik.length/2; i++){ 
				if (imenik[i]==null){
					imenik[i]=p;
					break;
				}}
		else
			for (int i = imenik.length/2; i < imenik.length; i++){ 
				if (imenik[i]==null){
					imenik[i]=p;
					break;
				}}
		
	}

	
}
