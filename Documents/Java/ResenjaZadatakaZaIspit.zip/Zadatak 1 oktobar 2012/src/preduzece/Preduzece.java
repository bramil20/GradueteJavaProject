package preduzece;

import java.io.Serializable;
import java.util.GregorianCalendar;

public class Preduzece implements Serializable {
	
	private int PIB;
	private String naziv, telefon;
	private GregorianCalendar datumRegistracije;
	
	public GregorianCalendar getDatumRegistracije() {
		return datumRegistracije;
	}

	public void setDatumRegistracije(GregorianCalendar datumRegistracije) {
		if (!datumRegistracije.before(new GregorianCalendar()))
			throw new RuntimeException("Datum registracije mora da se odnosi na proslost.");
		
		this.datumRegistracije = datumRegistracije;
	}

	public int getPIB() {
		return PIB;
	}
	
	public void setPIB(int pIB) {
		if (pIB<=0)
			throw new RuntimeException("PIB mora biti veci od nule");
		
		PIB = pIB;
	}
	
	public String getNaziv() {
		return naziv;
	}
	
	public void setNaziv(String naziv) {
		if (naziv==null || naziv.length()<3)
			throw new RuntimeException("Naziv mora imati makar tri znaka");
		
		this.naziv = naziv;
	}
	
	public String getTelefon() {
		return telefon;
	}
	
	public void setTelefon(String telefon) {
		if (telefon==null || telefon.length()<3 || !telefon.startsWith("0"))
			throw new RuntimeException("Telefon mora imati makar tri znaka i mora pocinjati nulom");
		
		this.telefon = telefon;
	}

	public String toString() {
		return "Preduzece [PIB=" + PIB + ", naziv=" + naziv + ", telefon="
				+ telefon + ", datumRegistracije=" + datumRegistracije + "]";
	}
	
	

}
