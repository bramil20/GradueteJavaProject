package preduzece.registar;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import preduzece.Preduzece;

public interface RegistarPreduzeca {
	
	public void dodajPreduzece(int PIB, String naziv, GregorianCalendar datumRegistracije, String telefon);

	public LinkedList<Preduzece> nadjiPreduzece(String deoNaziva);
}
