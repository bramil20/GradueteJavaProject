package vodostaj;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import vodostaj.reka.Reka;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.GregorianCalendar;

public class VodostajGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextArea textArea;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox_2;
	
	private Reka[] reke = new Reka[100];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VodostajGUI frame = new VodostajGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VodostajGUI() {
		setResizable(false);
		setTitle("Vodostaj");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNaziv = new JLabel("Naziv");
		lblNaziv.setBounds(12, 12, 70, 15);
		contentPane.add(lblNaziv);
		
		JLabel lblDanMesecGodina = new JLabel("Dan       Mesec      Godina");
		lblDanMesecGodina.setBounds(12, 70, 182, 15);
		contentPane.add(lblDanMesecGodina);
		
		JLabel lblVodostaj = new JLabel("Vodostaj");
		lblVodostaj.setBounds(12, 128, 70, 15);
		contentPane.add(lblVodostaj);
		
		textField = new JTextField();
		textField.setBounds(12, 39, 114, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(12, 155, 114, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setBorder(new LineBorder(new Color(0, 0, 0)));
		textArea.setBounds(194, 12, 242, 204);
		contentPane.add(textArea);
		
		JButton btnUnesi = new JButton("Unesi");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reka r = new Reka();
				r.setNaziv(textField.getText());
				r.setVodostaj(Double.parseDouble(textField_1.getText()));
				
				GregorianCalendar datumMerenja = new GregorianCalendar();
				datumMerenja.set(Integer.parseInt((String)(comboBox_2.getSelectedItem())),
						Integer.parseInt((String)(comboBox_1.getSelectedItem()))-1,
						Integer.parseInt((String)(comboBox.getSelectedItem())));
				r.setDatumMerenja(datumMerenja);
				
				for(int i=0;i<reke.length;i++)
					if (reke[i]==null){
						reke[i] = r;
						break;
					}
			}
		});
		btnUnesi.setBounds(41, 235, 117, 25);
		contentPane.add(btnUnesi);
		
		JButton btnPrikaziSve = new JButton("Prikazi sve");
		btnPrikaziSve.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("VODOSTAJ");
				
				double maxVodostaj = -1;
				String nazivMaxReke = null;
				
				for(int i=0;i<reke.length;i++)
					if (reke[i]!=null){
						//Prvo ispisuje reku u editoru
						textArea.append(reke[i].toString()+'\n');
						//Onda proverava da li je vodostaj veci od maksimalnog.
						//Ako jeste, onda je to novi maksimum.
						if (reke[i].getVodostaj()>maxVodostaj){
							maxVodostaj = reke[i].getVodostaj();
							nazivMaxReke = reke[i].getNaziv();
						}
					}
				
				//Ispis naziva reke sa max vodostajem
				textArea.append(nazivMaxReke);
						
			}
		});
		btnPrikaziSve.setBounds(170, 235, 117, 25);
		contentPane.add(btnPrikaziSve);
		
		JButton btnIzvestaj = new JButton("Izvestaj");
		btnIzvestaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					PrintWriter out = new PrintWriter(new FileWriter("izvestaj.txt"));
					
					//Prolazi se kroz niz sa dva brojaca. Ako se desi
					//da se oba nalaze na elementima koji nisu null i koji
					//predstavljaju istu reku ali dva razlicita merenja,
					//onda se proverava da li je vodostaj porastao za vise
					//od metar i ako jeste oba merenja se upisuju u fajl.
					for(int i=0;i<reke.length-1;i++){
						//Ako je ovaj element null, odmah se preskace iteracija
						//i ide se na sledeci element.
						if (reke[i]==null) continue;
						
						//Trazi se i proverava da li se u okviru
						//preostalih elemenata niza (onih "desno" od reke[i])
						//nalazi merenje za istu reku samo drugi datum
						for(int j=i+1;j<reke.length;j++)
							if (reke[j]!=null && reke[i].getNaziv().equals(reke[j].getNaziv()) &&
							((reke[i].getDatumMerenja().after(reke[j].getDatumMerenja()) &&
									reke[i].getVodostaj()-reke[j].getVodostaj()>1) || 
							 (reke[i].getDatumMerenja().before(reke[j].getDatumMerenja()) &&
											reke[j].getVodostaj()-reke[i].getVodostaj()>1))){
								out.println(reke[i]);
								out.print(reke[j]);
							}
								
					}
							
					
					out.close();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
		});
		btnIzvestaj.setBounds(299, 235, 117, 25);
		contentPane.add(btnIzvestaj);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox.setBounds(12, 92, 46, 24);
		contentPane.add(comboBox);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBox_1.setBounds(70, 92, 46, 24);
		contentPane.add(comboBox_1);
		
		comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"2010", "2011", "2012", "2013", "2014", "2015"}));
		comboBox_2.setBounds(128, 92, 66, 24);
		contentPane.add(comboBox_2);
	}
}
