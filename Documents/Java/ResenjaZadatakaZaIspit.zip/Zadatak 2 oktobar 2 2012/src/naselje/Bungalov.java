package naselje;

import java.io.Serializable;
import java.util.GregorianCalendar;

public class Bungalov implements Serializable {
	
	private int broj;
	private String ime;
	private GregorianCalendar zauzetDo;
	private boolean pogledNaMore;
	
	public int getBroj() {
		return broj;
	}
	
	public void setBroj(int broj) {
		if (broj<=0)
			throw new RuntimeException("Broj mora biti veci od nule");
		
		this.broj = broj;
	}
	
	public String getIme() {
		return ime;
	}
	
	public void setIme(String ime) {
		if (ime==null || ime.length()<=5)
			throw new RuntimeException("Ime ne sme biti null i mora imati vise od 5 znakova");
		
		this.ime = ime;
	}
	
	public GregorianCalendar getZauzetDo() {
		return zauzetDo;
	}
	
	public void setZauzetDo(GregorianCalendar zauzetDo) {
		if (zauzetDo.before(new GregorianCalendar()))
			throw new RuntimeException("Datum mora da bude neki iz buducnosti");
			
		this.zauzetDo = zauzetDo;
	}
	
	public boolean isPogledNaMore() {
		return pogledNaMore;
	}
	
	public void setPogledNaMore(boolean pogledNaMore) {
		this.pogledNaMore = pogledNaMore;
	}
	
	public String toString(){
		return "Broj:"+broj+" Ime turiste:"+ime+" Zauzet do:"+zauzetDo.getTime()+
				" Pogled na more:"+pogledNaMore;
	}

}
