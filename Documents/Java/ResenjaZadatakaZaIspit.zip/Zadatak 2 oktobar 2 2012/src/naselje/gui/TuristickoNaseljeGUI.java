package naselje.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import naselje.Bungalov;
import java.io.*;

public class TuristickoNaseljeGUI extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea;
	private JPanel panel;
	private JLabel lblImePrezime;
	private JTextField poljeZaUnosImena;
	private JLabel lblDanMesecGodina;
	private JTextField poljeZaUnosDana;
	private JTextField poljeZaUnosMeseca;
	private JTextField poljeZaUnosGodine;
	private JLabel lblPogledNaMore;
	private JComboBox comboBoxPogledNaMore;
	private JButton btnUcitaj;
	private JButton btnSacuvaj;
	private JButton btnRezervisi;

	private LinkedList<Bungalov> bungalovi = new LinkedList<Bungalov>();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TuristickoNaseljeGUI frame = new TuristickoNaseljeGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TuristickoNaseljeGUI() {
		setTitle("Bungalovi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 342);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		textArea = new JTextArea();
		contentPane.add(textArea, BorderLayout.CENTER);
		
		panel = new JPanel();
		panel.setPreferredSize(new Dimension(150, 10));
		contentPane.add(panel, BorderLayout.EAST);
		panel.setLayout(null);
		
		lblImePrezime = new JLabel("ime prezime");
		lblImePrezime.setBounds(12, 12, 86, 15);
		panel.add(lblImePrezime);
		
		poljeZaUnosImena = new JTextField();
		poljeZaUnosImena.setBounds(12, 31, 126, 19);
		poljeZaUnosImena.setPreferredSize(new Dimension(130, 19));
		panel.add(poljeZaUnosImena);
		poljeZaUnosImena.setColumns(10);
		
		lblDanMesecGodina = new JLabel("Dan Mesec Godina");
		lblDanMesecGodina.setBounds(12, 62, 138, 15);
		panel.add(lblDanMesecGodina);
		
		poljeZaUnosDana = new JTextField();
		poljeZaUnosDana.setBounds(12, 89, 26, 19);
		panel.add(poljeZaUnosDana);
		poljeZaUnosDana.setColumns(10);
		
		poljeZaUnosMeseca = new JTextField();
		poljeZaUnosMeseca.setBounds(50, 89, 26, 19);
		panel.add(poljeZaUnosMeseca);
		poljeZaUnosMeseca.setColumns(10);
		
		poljeZaUnosGodine = new JTextField();
		poljeZaUnosGodine.setBounds(86, 89, 52, 19);
		panel.add(poljeZaUnosGodine);
		poljeZaUnosGodine.setColumns(10);
		
		lblPogledNaMore = new JLabel("Pogled na more");
		lblPogledNaMore.setBounds(12, 124, 126, 15);
		panel.add(lblPogledNaMore);
		
		comboBoxPogledNaMore = new JComboBox();
		comboBoxPogledNaMore.setModel(new DefaultComboBoxModel(new String[] {"Da", "Ne"}));
		comboBoxPogledNaMore.setBounds(12, 151, 86, 24);
		panel.add(comboBoxPogledNaMore);
		
		btnUcitaj = new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Preuzimanje teksta sa nazivima fajlova iz editora i njegovo
				//deljenje na niz pojedinacnih naziva metodom split
				String[] nazivi = textArea.getText().split(" ");
				
				//Prolazi se kroz niz naziva i za svaki naziv (iz svakog fajla ciji je naziv dat)
				//se ucitavaju svi bungalovi i dodaju u listu
				for (int i = 0; i < nazivi.length; i++) 
					try{
						ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(nazivi[i])));
						
						try{
							while(true){
								Bungalov b = (Bungalov)in.readObject();
								bungalovi.add(b);
							}
						}catch(Exception e2){}
						
						in.close();
					}catch(Exception e1){
						e1.printStackTrace();
					}
				
				//Brisanje teksta iz editora i prikaz svih bungalova u editoru i to svaki u posebnom redu.
				textArea.setText("");
				for (int i=0;i<bungalovi.size();i++)
					textArea.append(bungalovi.get(i).toString()+'\n');
			}
		});
		btnUcitaj.setBounds(12, 199, 126, 25);
		panel.add(btnUcitaj);
		
		btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("sb.out")));
					GregorianCalendar trenutniDatum = new GregorianCalendar();
					
					//Prolazi se kroz listu i pronalaze se slobodni bungalovi.
					//To su oni kojima je datum zauzetDo vec prosao. Ti bungalovi se
					//onda upisuju u fajl serijalizacijom.
					for(int i=0;i<bungalovi.size();i++)
						if (bungalovi.get(i).getZauzetDo().before(trenutniDatum))
							out.writeObject(bungalovi.get(i));
					
					out.close();
				}catch(Exception e1){
					e1.printStackTrace();
				}
			}
		});
		btnSacuvaj.setBounds(12, 236, 126, 25);
		panel.add(btnSacuvaj);
		
		btnRezervisi = new JButton("Rezervisi");
		btnRezervisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Preuzimanje podataka o datumu i pravljenje GregorianCalendar objekta
				//koji predstavlja uneti datum.
				int dan = Integer.parseInt(poljeZaUnosDana.getText());
				int mesec = Integer.parseInt(poljeZaUnosMeseca.getText())-1;
				int godina = Integer.parseInt(poljeZaUnosGodine.getText());
				GregorianCalendar zeljeniDatum = new GregorianCalendar();
				zeljeniDatum.set(godina, mesec, dan);
				
				//Preuzimanje podatka o tome da li treba da ima pogled na more 
				boolean pogled = false;
				if (((String)comboBoxPogledNaMore.getSelectedItem()).equals("Da")) pogled = true;
				
				//Prolazi se kroz listu i traze se bungalovi koji ce biti slobodni u vreme
				//zeljenog datuma i koji imaju tj. nemaju pogled na more.
				for (int i=0;i<bungalovi.size();i++)
					if (bungalovi.get(i).getZauzetDo().before(zeljeniDatum) &&
							bungalovi.get(i).isPogledNaMore()==pogled){
						//Kad se takav bungalov nadje,postavlja se ime osobe, datum zauzetDo
						//se postavlja na zeljeni datum i ispisuje se broj bungalova u editoru.
						//Onda se prekida for petlja.
						bungalovi.get(i).setIme(poljeZaUnosImena.getText());
						bungalovi.get(i).setZauzetDo(zeljeniDatum);
						textArea.setText(""+bungalovi.get(i).getBroj());
						break;
					}
				
				
				
			}
		});
		btnRezervisi.setBounds(12, 273, 126, 25);
		panel.add(btnRezervisi);
	}
}
