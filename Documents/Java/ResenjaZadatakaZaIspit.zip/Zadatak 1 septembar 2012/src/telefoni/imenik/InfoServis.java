package telefoni.imenik;

import java.util.LinkedList;

import telefoni.pretplatnik.Pretplatnik;

public interface InfoServis {
	
	public void dodajPretplatnika(String imePrezime, String adresa, int telefon);
	
	public LinkedList<Pretplatnik> nadjiPretplatnika();
	
	public void vratiInformator(String[] niz);
	

}
