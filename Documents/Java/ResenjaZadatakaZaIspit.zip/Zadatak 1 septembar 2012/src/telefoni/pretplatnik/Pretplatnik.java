package telefoni.pretplatnik;

public class Pretplatnik {
	
	private String imePrezime, adresa;
	private int telefon;
	
	public String getImePrezime() {
		return imePrezime;
	}
	
	public void setImePrezime(String imePrezime) {
		if (imePrezime==null || imePrezime.length()<5)
			throw new RuntimeException("Ime mora biti uneto i mora biti duze od pet znakova");
		
		this.imePrezime = imePrezime;
	}
	
	public String getAdresa() {
		return adresa;
	}
	
	public void setAdresa(String adresa) {
		if (adresa==null || adresa.length()<5)
			throw new RuntimeException("Adresa mora biti uneta i mora biti duza od pet znakova");
		
		this.adresa = adresa;
	}
	
	public int getTelefon() {
		return telefon;
	}
	
	public void setTelefon(int telefon) {
		if (telefon<10000)
			throw new RuntimeException("Telefon mora imati bar 5 cifara");
		
		this.telefon = telefon;
	}

	public String toString() {
		return "Pretplatnik [imePrezime=" + imePrezime + ", adresa=" + adresa
				+ ", telefon=" + telefon + "]";
	}
	
	
	
	

}
