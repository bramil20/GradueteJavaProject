package telefoni;

import java.util.Iterator;
import java.util.LinkedList;
import java.io.*;
import telefoni.imenik.InfoServis;
import telefoni.pretplatnik.Pretplatnik;

public class Info988 implements InfoServis {

	private LinkedList<Pretplatnik> imenik;
	
	public Info988(){
		imenik = new LinkedList<Pretplatnik>();
	}
	
	public void dodajPretplatnika(String imePrezime, String adresa, int telefon) {
		//Samo se proveravaju ova dva parametra jer telefon ne moze da bude null
		if (imePrezime!=null && adresa!=null){
			Pretplatnik novi = new Pretplatnik();
			novi.setImePrezime(imePrezime);
			novi.setAdresa(adresa);
			novi.setTelefon(telefon);
			
			imenik.add(novi);
		}
		else{
			try{
				PrintWriter out = new PrintWriter(new FileWriter("log.txt"));
				
				out.println("Greska! "+imePrezime + adresa + telefon);
				
				out.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	
	}

	public LinkedList<Pretplatnik> nadjiPretplatnika() {
		LinkedList<Pretplatnik> novaLista = new LinkedList<Pretplatnik>();
		String deoAdrese = null;
		
		//Ucitavanje adrese ili njenog dela sa tastature
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			deoAdrese = br.readLine(); 
		}catch(Exception e){
			e.printStackTrace();
		}
		
		//Prolazenje kroz imenik i trazenje pretplatnika koji u
		//u okviru adrese imaju uneti String. Kad se nadju,
		//unose se u novu listu.
		for (int i=0;i<imenik.size();i++)
			if (imenik.get(i).getAdresa().indexOf(deoAdrese)!=-1)
				novaLista.add(imenik.get(i));
		
		return novaLista;
	}

	public void vratiInformator(String[] niz) {
		try{
			PrintWriter out = new PrintWriter(new FileWriter("imenik988.txt"));
			
			//Prolazi se kroz niz svih naziva ulica
			for (int i = 0; i < niz.length; i++)
				//Za svaki naziv ulice iz niza se po jednom prodje kroz ceo 
				//imenik i trazi se da adresa pretplatnika pocinje sa trazenim
				//nazivom ulice. Ako se nadje takav pretplatnik, upisuje se u fajl.
				for (int j=0;j<imenik.size();j++)
					if (imenik.get(j).getAdresa().startsWith(niz[i]))
						out.println(imenik.get(j));
				
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
