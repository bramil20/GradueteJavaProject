import java.io.Serializable;

public class Radnik implements Serializable {

	private String imePrezime;
	private int godineStarosti;
	private int godineStaza;
	private boolean pol;

	public String getImePrezime() {
		return imePrezime;
	}

	public void setImePrezime(String imePrezime) {
		if (imePrezime == null || imePrezime.length() > 20) {
			throw new RadnikException("Ime i prezime ne moze biti null ili duze od dvadeset znakova.");
		}
		this.imePrezime = imePrezime;
	}

	public int getGodineStarosti() {
		return godineStarosti;
	}

	public void setGodineStarosti(int godineStarosti) {
		if (godineStarosti < 0) {
			throw new RadnikException("Godine starosti ne mogu biti manje od nule.");
		}
		this.godineStarosti = godineStarosti;
	}

	public int getGodineStaza() {
		return godineStaza;
	}

	public void setGodineStaza(int godineStaza) {
		if (godineStaza < 0) {
			throw new RadnikException("Godine staza ne mogu biti manje od nule.");
		}
		this.godineStaza = godineStaza;
	}

	public boolean isPol() {
		return pol;
	}

	public void setPol(boolean pol) {
		this.pol = pol;
	}

	@Override
	public String toString() {
		return "Ime i prezime: "+imePrezime+"\t, godine starosti: "+godineStarosti+"\t, godine staza: "+godineStaza+
				"\t, pol: "+pol;
	}
	
}
