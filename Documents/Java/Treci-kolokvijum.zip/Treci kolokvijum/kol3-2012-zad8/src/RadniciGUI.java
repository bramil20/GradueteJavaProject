import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class RadniciGUI extends JFrame {

	private JPanel contentPane;
	
	private JTextField jtfImePrezime;
	private JTextField jtfGodineStaza;
	private JTextField jtfGodineStarosti;

	private LinkedList<Radnik> radnici = new LinkedList<Radnik>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RadniciGUI frame = new RadniciGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RadniciGUI() {
		setTitle("Radnici");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 530, 357);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(100, 120));
		contentPane.add(panel, BorderLayout.SOUTH);
		
		final JTextArea textArea = new JTextArea();
		contentPane.add(textArea, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNaziv = new JLabel("Ime i prezime");
		lblNaziv.setBounds(16, 6, 133, 16);
		panel.add(lblNaziv);
		
		jtfImePrezime = new JTextField();
		jtfImePrezime.setBounds(15, 26, 134, 20);
		panel.add(jtfImePrezime);
		jtfImePrezime.setColumns(10);
		
		JLabel lblGodinaUpisa = new JLabel("Pol");
		lblGodinaUpisa.setBounds(16, 66, 134, 16);
		panel.add(lblGodinaUpisa);
		
		JLabel lblBrojMesta = new JLabel("Godine staza");
		lblBrojMesta.setBounds(180, 6, 134, 16);
		panel.add(lblBrojMesta);
		
		JLabel lblBrojPrijavljenih = new JLabel("Godine starosti");
		lblBrojPrijavljenih.setBounds(180, 66, 134, 16);
		panel.add(lblBrojPrijavljenih);
		
		jtfGodineStaza = new JTextField();
		jtfGodineStaza.setColumns(10);
		jtfGodineStaza.setBounds(180, 26, 134, 20);
		panel.add(jtfGodineStaza);
		
		jtfGodineStarosti = new JTextField();
		jtfGodineStarosti.setColumns(10);
		jtfGodineStarosti.setBounds(180, 86, 134, 20);
		panel.add(jtfGodineStarosti);
		
		final JComboBox jcbPol = new JComboBox();
		jcbPol.setBounds(16, 84, 133, 27);
		jcbPol.addItem("muski");
		jcbPol.addItem("zenski");
		panel.add(jcbPol);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtfImePrezime.setText(null);
				jtfGodineStaza.setText(null);
				jtfGodineStarosti.setText(null);
			}
		});
		btnObrisi.setBounds(351, 17, 117, 29);
		panel.add(btnObrisi);
		
		JButton btnUcitaj = new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nazivFajla = textArea.getText();
				
				try{
					ObjectInputStream in = new ObjectInputStream(
							new FileInputStream(nazivFajla));
					
					try {
						while (true) {
							Radnik p = (Radnik) (in.readObject());
							
							radnici.add(p);
						}
					} catch (Exception ex) {
					}
					
					// zatvaramo stream
					in.close();
					
					// ispisujemo sadrzaj liste u editoru
					String tekst = "";
					
					for (int i = 0; i < radnici.size(); i++) {
						tekst += radnici.get(i) + "\n";
					}
					
					textArea.setText(tekst);
				} catch (Exception ex) {
					System.out.println("Greska: " + ex.getMessage());
				}
			}
		});
		btnUcitaj.setBounds(351, 50, 117, 29);
		panel.add(btnUcitaj);
		
		JButton btnUnesi = new JButton("Unesi");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String imePrezime = null;
				try {
					imePrezime = jtfImePrezime.getText();
				} catch (NumberFormatException nfe) {
					jtfImePrezime.setText("GRESKA");
				}
				
				int godineStarosti = 0;
				try {
					godineStarosti = Integer.parseInt(jtfGodineStarosti.getText());
				} catch (NumberFormatException nfe) {
					jtfGodineStarosti.setText("GRESKA");
				}
				
				int godineStaza = 0;
				try {
					godineStaza = Integer.parseInt(jtfGodineStaza.getText());
				} catch (NumberFormatException nfe) {
					jtfGodineStaza.setText("GRESKA");
				}
				
				String polString = jcbPol.getSelectedItem().toString();
				
				boolean pol;
				if (polString.equals("muski")) {
					pol = false;
				} else {
					pol = true;
				}
				
				Radnik noviRadnik = new Radnik();
				noviRadnik.setImePrezime(imePrezime);
				noviRadnik.setGodineStarosti(godineStarosti);
				noviRadnik.setGodineStaza(godineStaza);
				noviRadnik.setPol(pol);
				
				if (!radnici.contains(noviRadnik)) {
					radnici.add(noviRadnik);
				}
			}
		});
		btnUnesi.setBounds(351, 83, 117, 29);
		panel.add(btnUnesi);
		
	
	}
}
