
public class RadnikException extends RuntimeException {

	public RadnikException(String message) {
		super(message);
	}
}
