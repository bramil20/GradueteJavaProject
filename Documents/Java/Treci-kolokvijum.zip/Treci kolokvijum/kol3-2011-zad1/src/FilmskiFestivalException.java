
public class FilmskiFestivalException extends RuntimeException {

	public FilmskiFestivalException(String message) {
		super(message);
	}
}
