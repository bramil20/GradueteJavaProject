import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileInputStream;
import java.io.ObjectInputStream;


public class GradoviGUI extends JFrame {

	private JPanel contentPane;
	private JTextField jtfEditor;
	
	private LinkedList<Grad> gradovi = new LinkedList<Grad>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GradoviGUI frame = new GradoviGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GradoviGUI() {
		setTitle("Lista gradova");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(200, 50));
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnUcitaj = new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// prvo brisemo sadrzaj liste
					gradovi.clear();
					
					// ucitavamo sadrzaj iz prvog fajla i unosimo sve gradove u listu
					ObjectInputStream arhiva1In = new ObjectInputStream(
							new FileInputStream("arhiva1.out"));

					try {
						while (true) {
							Grad g = (Grad) (arhiva1In.readObject());
							gradovi.add(g);
						}
					} catch (Exception ex) { 
					}

					arhiva1In.close();
					
					// ucitavamo sadrzaj iz drugog fajla i unosimo one gradove koji se vec ne nalaze u listi
					ObjectInputStream arhiva2In = new ObjectInputStream(
							new FileInputStream("arhiva2.out"));
					
					try {
						while (true) {
							Grad g = (Grad) (arhiva2In.readObject());
							
							// proveravamo da li se ovaj grad vec nalazi u listi
							if (!gradovi.contains(g)) {
								gradovi.add(g);
							}
						}
					} catch (Exception ex) { 
					}
					
					arhiva2In.close();
				} catch (Exception ex) {
					System.out.println("Greska: " + ex.getMessage());
				}
			}
		});
		panel.add(btnUcitaj);
		
		JButton btnIspisi = new JButton("Ispisi");
		btnIspisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (gradovi.isEmpty()) {
					jtfEditor.setText("Lista je prazna");
				} else {
					// PRVI NACIN
					
					// trazimo prvi grad po broju stanovnika
					Grad prviPoBrStanovika = null;
					
					for (int i = 0; i < gradovi.size(); i++) {
						// ovaj uslov ce biti zadovoljen samo prvi put
						if (prviPoBrStanovika == null) {
							prviPoBrStanovika = gradovi.get(i);
						} 
						
						// Proveravamo da li tekuci grad (sa indeksom 'i') ima vise stanovnika od
						// trenutnog prviPoBrStanovika. Ukoliko ima, taj grad postaje prviPoBrStanovika.
						else if (gradovi.get(i).getBrojStanovnika() > prviPoBrStanovika.getBrojStanovnika()) {
							prviPoBrStanovika = gradovi.get(i);
						}
					}
					
					// trazimo drugi grad po broju stanovnika
					Grad drugiPoBrStanovika = null;
					
					for (int i = 0; i < gradovi.size(); i++) {
						// ukoliko smo naisli na prviPoBrStanovika, njega preskacemo
						if (gradovi.get(i).equals(prviPoBrStanovika)) {
							continue;
						}
						
						// ukoliko drugiPoBrStanovika nije postavljen 
						if (drugiPoBrStanovika == null) {
							drugiPoBrStanovika = gradovi.get(i);
						} 
						
						// Proveravamo da li tekuci grad (sa indeksom 'i') ima vise stanovnika od
						// drugiPoBrStanovika. Ukoliko ima, tekuci grad postaje drugiPoBrStanovika.
						else if (gradovi.get(i).getBrojStanovnika() > drugiPoBrStanovika.getBrojStanovnika()) {
							drugiPoBrStanovika = gradovi.get(i);
						}
					}
					
					// trazimo treci grad po broju stanovnika
					Grad treciPoBrStanovika = null;
					
					for (int i = 0; i < gradovi.size(); i++) {
						// ukoliko smo naisli na prviPoBrStanovika ili drugiPoBrStanovika, njega preskacemo
						if (gradovi.get(i).equals(prviPoBrStanovika) || gradovi.get(i).equals(drugiPoBrStanovika)) {
							continue;
						}
						
						// ukoliko treciPoBrStanovika nije postavljen 
						if (treciPoBrStanovika == null) {
							treciPoBrStanovika = gradovi.get(i);
						} 
						
						// Proveravamo da li tekuci grad (sa indeksom 'i') ima vise stanovnika od
						// treciPoBrStanovika. Ukoliko ima, tekuci grad postaje treciPoBrStanovika.
						else if (gradovi.get(i).getBrojStanovnika() > treciPoBrStanovika.getBrojStanovnika()) {
							treciPoBrStanovika = gradovi.get(i);
						}
					}
					
					// dodajemo tekst u editor
					jtfEditor.setText(prviPoBrStanovika + "/n" + drugiPoBrStanovika + "/n" + treciPoBrStanovika);
					
					
					
					// DRUGI NACIN
					
					// prvo cemo napraviti sortiranu listu svih gradova u opadajucem redosledu po broju stanovnika
					LinkedList<Grad> sortiranaListaGradova = new LinkedList<Grad>();
					
					// prolazimo kroz postojecu listu i svaki grad dodajemo na odgovarajuce mesto u novoj
					// sortiranoj listi
					for (int i = 0; i < gradovi.size(); i++) {
						Grad grad = gradovi.get(i);
						
						// ovaj uslov je zadovoljen kada unosimo prvi grad
						if (sortiranaListaGradova.isEmpty()) {
							sortiranaListaGradova.add(grad);
						} else {
							// promenljiva 'unesen' nam sluzi kao indikator da li je grad vec unesen
							boolean unesen = false;
							
							for (int j = 0; j < sortiranaListaGradova.size(); j++) {
								if (sortiranaListaGradova.get(j).getBrojStanovnika() < grad.getBrojStanovnika()) {
									sortiranaListaGradova.add(j, grad);
									unesen = true;
									// ovaj break se odnosi na unutrasnju for petlju
									break;
								}
							}
							
							// Ukoliko svi gradovi u sortiranoj listi imaju broj stanovnika koji je veci od broja  
							// stanovnika grada koji unosimo, uslov u prethodnoj petlji nece nijednom biti ispunjen i  
							// vrednost promenljive 'unesen' ce ostati false. Odnosno, vrednost false oznacava da grad 
							// jos nije unesen. U tom slucaju, grad treba uneti na kraj liste.
							if (!unesen) {
								sortiranaListaGradova.addLast(grad);
							}
						}
					}
					
					// Kada kada imamo sortiranu listu gradova, dovoljno je da ispisemo podatke prva tri grada.
					String tekstZaEditor = "";
					for (int i = 0; i < 3; i++) {
						tekstZaEditor += sortiranaListaGradova.get(i) + "/n";
					}
					
					jtfEditor.setText(tekstZaEditor);
				}
			}
		});
		panel.add(btnIspisi);
		
		JButton btnIzadji = new JButton("Izadji");
		btnIzadji.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		panel.add(btnIzadji);
		
		jtfEditor = new JTextField();
		contentPane.add(jtfEditor, BorderLayout.CENTER);
		jtfEditor.setColumns(10);
	}

}
