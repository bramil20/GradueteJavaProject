import java.io.Serializable;

public class Grad implements Serializable {

	private String naziv;
	private int brojStanovnika;

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		if (naziv == null) {
			throw new GradException("Naziv ne moze biti null");
		}
		this.naziv = naziv;
	}

	public int getBrojStanovnika() {
		return brojStanovnika;
	}

	public void setBrojStanovnika(int brojStanovnika) {
		if (brojStanovnika <= 0) {
			throw new GradException("Broj stanovnika mora biti veci od nule.");
		}
		this.brojStanovnika = brojStanovnika;
	}
	
	@Override
	public String toString() {
		return "NAZIV GRADA: " + naziv + " BROJ STANOVNIKA: " + brojStanovnika;
	}
}
