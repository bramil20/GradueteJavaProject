import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;

public class ArhivaFestivala {

	private LinkedList<MuzickiFestival> festivali = new LinkedList<MuzickiFestival>();

	public void upisiFestivaleUcesnika(String nazivIzvodjaca) throws Exception {
		if (festivali.isEmpty()) {
			throw new Exception("Ne postoje uneti festivali.");
		}

		try {
			ObjectOutputStream out = new ObjectOutputStream(
					new BufferedOutputStream(new FileOutputStream(
							"osvojeni_festivali.out")));

			for (int i = 0; i < festivali.size(); i++) {
				if (festivali.get(i).getPobednik().equals(nazivIzvodjaca)) {
					out.writeObject(festivali.get(i));
				}
			}
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}

	public void ucitajFestivaleIzFajla() {
		try {
			DataInputStream in = new DataInputStream(new BufferedInputStream(
					new FileInputStream("arhiva.out")));

			while (in.available() != 0) {
				String naziv = in.readUTF();
				String mesto = in.readUTF();
				String pobednik = in.readUTF();

				MuzickiFestival f = new MuzickiFestival();
				f.setNazivFestivala(naziv);
				f.setMestoOdrzavanja(mesto);
				f.setPobednik(pobednik);

				festivali.add(f);
			}
			in.close();
		} catch (Exception e) {
		}
	}

	public void ucitajCeluArhivu(LinkedList<String> spisakFajlova) {

		LinkedList<MuzickiFestival> objedinjeniFestivali = new LinkedList<MuzickiFestival>();

		// posto se u listi 'spisakFajlova' nalaze nazivi fajlova u kojima se nalaze podaci o 
		// festivalima, prolazimo kroz sve nazive fajlova, pristupamo svakom od njih, iscitavamo 
		// podatke o festivalima iz njega i smestamo u listu 'objedinjeniFestivali'
		for (int i = 0; i < spisakFajlova.size(); i++) {
			try {
				ObjectInputStream in = new ObjectInputStream(
						new FileInputStream(spisakFajlova.get(i)));

				try {
					while (true) {
						MuzickiFestival o = (MuzickiFestival) (in.readObject());

						if (!objedinjeniFestivali.contains(o)) {
							objedinjeniFestivali.add(o);
						}
					}
				} catch (Exception e) {
				}

				in.close();
			} catch (Exception e) {
				System.out.println("Greska: " + e.getMessage());
			}
		}

		// upisivanje objedinjene liste festivala u fajl cela_arhiva.out
		try {
			ObjectOutputStream out = new ObjectOutputStream(
					new BufferedOutputStream(new FileOutputStream(
							"cela_arhiva.out")));
			
			for (int i = 0; i < objedinjeniFestivali.size(); i++) {
				out.writeObject(objedinjeniFestivali.get(i));
			}
			
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
}
