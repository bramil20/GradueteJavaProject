import java.io.Serializable;

public class MuzickiFestival implements Serializable {

	private String nazivFestivala;
	private String mestoOdrzavanja;
	private String pobednik;

	public String getNazivFestivala() {
		return nazivFestivala;
	}

	public void setNazivFestivala(String nazivFestivala) {
		if (nazivFestivala == null || nazivFestivala.equals("")) {
			throw new MuzickiFestivalException("Naziv festivala ne moze biti null ili prazan string.");
		}
		this.nazivFestivala = nazivFestivala;
	}

	public String getMestoOdrzavanja() {
		return mestoOdrzavanja;
	}

	public void setMestoOdrzavanja(String mestoOdrzavanja) {
		if (mestoOdrzavanja == null || mestoOdrzavanja.equals("")) {
			throw new MuzickiFestivalException("Mesto odrzavanja festivala ne moze biti null ili prazan string.");
		}
		this.mestoOdrzavanja = mestoOdrzavanja;
	}

	public String getPobednik() {
		return pobednik;
	}

	public void setPobednik(String pobednik) {
		if (pobednik == null || pobednik.equals("")) {
			throw new MuzickiFestivalException("Pobednik festivala ne moze biti null ili prazan string.");
		}
		this.pobednik = pobednik;
	}

	@Override
	public boolean equals(Object obj) {
		MuzickiFestival ff = (MuzickiFestival) obj;
		
		if (this.getNazivFestivala().equals(ff.getNazivFestivala()) && 
				this.getMestoOdrzavanja().equals(ff.getMestoOdrzavanja())) {
			return true;
		}
		return false;
	}
}
