
public class MuzickiFestivalException extends RuntimeException {

	public MuzickiFestivalException(String message) {
		super(message);
	}
}
