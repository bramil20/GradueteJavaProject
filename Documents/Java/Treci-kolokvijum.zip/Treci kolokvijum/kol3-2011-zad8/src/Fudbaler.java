import java.io.Serializable;


public class Fudbaler implements Serializable {

	private String imePrezime;
	private int golovi;

	public String getImePrezime() {
		return imePrezime;
	}

	public void setImePrezime(String imePrezime) {
		if (imePrezime == null || imePrezime.equals("")) {
			throw new SportException("Ime i prezime ne moze biti null, niti prazan string.");
		}
		this.imePrezime = imePrezime;
	}

	public int getGolovi() {
		return golovi;
	}

	public void setGolovi(int golovi) {
		if (golovi < 0) {
			throw new SportException("Golovi ne mogu biti manji od nule.");
		}
		this.golovi = golovi;
	}
	
	@Override
	public String toString() {
		return "Ime i prezime: " + imePrezime + ", golovi: " + golovi;
	}
}
