
public class SportException extends RuntimeException {

	public SportException(String message) {
		super(message);
	}
}
