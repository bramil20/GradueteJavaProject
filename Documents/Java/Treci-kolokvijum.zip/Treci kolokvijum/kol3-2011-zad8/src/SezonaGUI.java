import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;


public class SezonaGUI extends JFrame {

	private JPanel contentPane;
	
	private LinkedList<Fudbaler> fudbaleri = new LinkedList<Fudbaler>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SezonaGUI frame = new SezonaGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SezonaGUI() {
		setTitle("Fudbaleri");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(100, 200));
		contentPane.add(panel, BorderLayout.EAST);
		
		final JTextArea jtaEditor = new JTextArea();
		contentPane.add(jtaEditor, BorderLayout.CENTER);
		
		JButton btnUcitaj = new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					// brisemo sadrzaj liste
					fudbaleri.clear();
					
					ObjectInputStream in = new ObjectInputStream(
							new FileInputStream("fudbaleri.out"));

					try {
						while (true) {
							Fudbaler f = (Fudbaler) (in.readObject());
							
							if (f.getGolovi() >= 3) {
								fudbaleri.add(f);
							}
						}
					} catch (Exception ex) { 
					}

					in.close();
				} catch (Exception ex) {
					System.out.println("Greska: " + ex.getMessage());
				}
			}
		});
		panel.add(btnUcitaj);
		
		JButton btnIspisi = new JButton("Ispisi");
		btnIspisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!fudbaleri.isEmpty()) {
					Fudbaler najuspesnijiStrelac = fudbaleri.get(0);
					
					for (int i = 1; i < fudbaleri.size(); i++) {
						if (fudbaleri.get(i).getGolovi() > najuspesnijiStrelac.getGolovi()) {
							najuspesnijiStrelac = fudbaleri.get(i);
						}
					}
					
					String sadrzajEditora = "";
					
					sadrzajEditora += najuspesnijiStrelac.toString();
					sadrzajEditora += "\n";
					
					// prolazimo kroz sve nagrade koje su smestene u fajlu 'nagrade.out' i ispisujemo 
					// one za koje najuspesniji fudbaler ima dovoljan broj golova
					try {
						DataInputStream in = new DataInputStream(
													new BufferedInputStream(
															new FileInputStream("nagrade.out")));

						while (in.available() != 0) {
							String nazivNagrade = in.readUTF();
							int brojGolova = in.readInt();
							
							if (najuspesnijiStrelac.getGolovi() >= brojGolova) {
								sadrzajEditora += nazivNagrade + "\n";
							}
						}
						in.close();
					} catch (Exception e) {
						System.out.println("Greska: " + e.getMessage());
					}
					
					// ispisujemo tekst u editoru
					jtaEditor.setText(sadrzajEditora);
				}
			}
		});
		panel.add(btnIspisi);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtaEditor.setText(null);
			}
		});
		panel.add(btnObrisi);
	}

}
