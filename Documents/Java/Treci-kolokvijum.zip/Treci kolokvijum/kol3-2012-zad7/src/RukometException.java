
public class RukometException extends RuntimeException {

	public RukometException(String message) {
		super(message);
	}
}
