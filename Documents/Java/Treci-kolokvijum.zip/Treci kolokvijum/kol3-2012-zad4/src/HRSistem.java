import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.LinkedList;

public class HRSistem {

	private LinkedList<Zaposleni> zaposleni = new LinkedList<Zaposleni>();
	
	public void napraviIzvestajZaJubilarnuNagradu() throws HRException {
		try {
			DataOutputStream out = new DataOutputStream(
					new BufferedOutputStream(
							new FileOutputStream("izvestaj.out")));
			
			for (int i = 0; i < zaposleni.size(); i++) {
				if (zaposleni.get(i).getGodineStaza() >= 10) {
					out.writeUTF(zaposleni.get(i).getImePrezime());
					out.writeInt(zaposleni.get(i).getGodineStaza());
				}
			}
			
			// zatvaramo stream
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}

	public void napraviIzvestajZaPenziju() throws HRException {
		try {
			ObjectOutputStream out = new ObjectOutputStream(
					new BufferedOutputStream(
							new FileOutputStream("skora_penzija.out")));
			
			int brojZaposlenihSpremnihNaPenziju = 0;
			
			for (int i = 0; i < zaposleni.size(); i++) {
				if ((zaposleni.get(i).getPol() == 'm' && 
						(zaposleni.get(i).getGodineStarosti() >= 65 || zaposleni.get(i).getGodineStaza() >= 40)) 
						||
					(zaposleni.get(i).getPol() == 'z' && 
						(zaposleni.get(i).getGodineStarosti() >= 60 || zaposleni.get(i).getGodineStaza() >= 35))) {
					
					out.writeObject(zaposleni.get(i));
					
					brojZaposlenihSpremnihNaPenziju++;
				}
			}
			
			out.close();
			
			System.out.println("Ukupan broj zaposlenih spremnih za penziju je: "+brojZaposlenihSpremnihNaPenziju);
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
	
	public void unesiZaposlenog () {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		try {
			Zaposleni radnik = new Zaposleni();

			System.out.print("Unesite ime i prezime: ");
			
			// koristimo kao indikator da li je uspesno uneseno ime
			boolean uspesanUnosImena = false;
			
			// sve dok ne bude uspesan unos imena, pokusavaj novi unos
			while (!uspesanUnosImena) {
				try {
					String imePrezime = br.readLine();
					radnik.setImePrezime(imePrezime);
					
					uspesanUnosImena = true;
				} catch (NumberFormatException nfe) {
					System.out.println("Greska prilikom unosa imena: " + nfe.getMessage());
					uspesanUnosImena = false;
				}
			}
			
			System.out.print("Unesite godine starosti: ");

			boolean uspesanUnosGodStarosti = false;
			
			// sve dok ne bude uspesan unos godina starosti, pokusavaj novi unos
			while (!uspesanUnosGodStarosti) {
				try {
					int godineStarosti = Integer.parseInt(br.readLine());
					radnik.setGodineStarosti(godineStarosti);
					
					uspesanUnosGodStarosti = true;
				} catch (NumberFormatException nfe) {
					System.out.println("Greska prilikom unosa godina starosti: " + nfe.getMessage());
					uspesanUnosGodStarosti = false;
				}
			}
			
			System.out.print("Unesite godine staza: ");
			
			boolean uspesanUnosGodStaza = false;
			
			// sve dok ne bude uspesan unos godina staza, pokusavaj novi unos
			while (!uspesanUnosGodStaza) {
				try {
					int godineStaza = Integer.parseInt(br.readLine());
					radnik.setGodineStaza(godineStaza);
					
					uspesanUnosGodStaza = true;
				} catch (NumberFormatException nfe) {
					System.out.println("Greska prilikom unosa godina staza: " + nfe.getMessage());
					uspesanUnosGodStaza = false;
				}
			}
			
			System.out.print("Unesite pol (m ili z): ");
			
			boolean uspesanUnosPola = false;
			
			// sve dok ne bude uspesan unos pola, pokusavaj novi unos
			while (!uspesanUnosPola) {
				try {
					char pol = br.readLine().charAt(0);
					radnik.setPol(pol);
					
					uspesanUnosPola = true;
				} catch (NumberFormatException nfe) {
					System.out.println("Greska prilikom unosa pola: " + nfe.getMessage());
					uspesanUnosPola = false;
				}
			}
			
			zaposleni.add(radnik);
		} catch (IOException e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
	
}
