
public class HRException extends Exception {

	public HRException(String message) {
		super(message);
	}
}
