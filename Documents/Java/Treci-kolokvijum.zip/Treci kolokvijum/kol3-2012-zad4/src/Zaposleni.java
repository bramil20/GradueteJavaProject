import java.io.Serializable;

public class Zaposleni implements Serializable {

	private String imePrezime;
	private int godineStarosti;
	private int godineStaza;
	private char pol;

	public String getImePrezime() {
		return imePrezime;
	}

	public void setImePrezime(String imePrezime) {
		if (imePrezime == null || imePrezime.length() > 20) {
			throw new RuntimeException("Ime prezime ne moze biti null ili duze od dvadeset znakova.");
		}
		this.imePrezime = imePrezime;
	}

	public int getGodineStarosti() {
		return godineStarosti;
	}

	public void setGodineStarosti(int godineStarosti) {
		if (godineStarosti < 0) {
			throw new RuntimeException("Godine starosti ne mogy biti manje od nule.");
		}
		this.godineStarosti = godineStarosti;
	}

	public int getGodineStaza() {
		return godineStaza;
	}

	public void setGodineStaza(int godineStaza) {
		if (godineStaza < 0) {
			throw new RuntimeException("Godine staza ne mogu biti manje od nule.");
		}
		this.godineStaza = godineStaza;
	}

	public char getPol() {
		return pol;
	}

	public void setPol(char pol) {
		if (pol == 'm' || pol == 'z') {
			throw new RuntimeException("Pol mora biti 'm' ili 'z'.");
		}
		this.pol = pol;
	}

	@Override
	public String toString() {
		return "Ime i prezime: "+imePrezime+"\t, godine starosti: "+godineStarosti+"\t, godine staza: "+godineStaza+"\t, pol: "+pol;
	}
	
	@Override
	public boolean equals(Object obj) {
		Zaposleni opstina = (Zaposleni) obj;
		
		if (this.getImePrezime().equals(opstina.getImePrezime()) && 
				this.getGodineStarosti() == opstina.getGodineStarosti()) {
			return true;
		}
		return false;
	}
}
