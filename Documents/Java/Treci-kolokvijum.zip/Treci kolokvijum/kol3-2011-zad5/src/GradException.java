
public class GradException extends RuntimeException {

	public GradException(String message) {
		super(message);
	}
}
