import java.awt.EventQueue;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;


public class GradoviGUI extends JFrame {

	private JPanel contentPane;
	private JTextField jtfNazivGrada;
	private JTextField jtfBrojStanovnika;
	
	private LinkedList<Grad> gradovi = new LinkedList<Grad>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GradoviGUI frame = new GradoviGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GradoviGUI() {
		setResizable(false);
		setTitle("Gradovi GUI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 431, 190);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNazivGrada = new JLabel("Naziv grada");
		lblNazivGrada.setBounds(29, 19, 116, 16);
		contentPane.add(lblNazivGrada);
		
		JLabel lblBrojStanovnika = new JLabel("Broj stanovnika");
		lblBrojStanovnika.setBounds(230, 19, 145, 16);
		contentPane.add(lblBrojStanovnika);
		
		JButton btnDodaj = new JButton("Dodaj");
		btnDodaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					String naziv = jtfNazivGrada.getText();
					int brojStanovnika = Integer.parseInt(jtfBrojStanovnika.getText());

					Grad noviGrad = new Grad();
					noviGrad.setNaziv(naziv);
					noviGrad.setBrojStanovnika(brojStanovnika);
					
					if (!gradovi.contains(noviGrad)) {
						// uzimamo u obzir situaciju kada je lista prazna
						if (gradovi.isEmpty()) {
							gradovi.add(noviGrad);
						} else {
							
							// ova promenljiva nam sluzi kao indikator da znamo da li smo uneli grad u listu ili ne
							boolean unesen = false;
							
							for (int i = 0; i < gradovi.size(); i++) {
								if (gradovi.get(i).getBrojStanovnika() < noviGrad.getBrojStanovnika()) {
									gradovi.add(i, noviGrad);
									unesen = true;
									break;
								}
							}
							
							// Kada promenljiva 'unesen' ima vrednost false oznacava situaciju kada u listi 
							// svi gradovi imaju veci broj stanovnika od novog grada i stoga uslov u petlji nijednom 
							// nije bio ispunjen. U tom slucaju, novi grad unosimo na kraj liste.
							if (!unesen) {
								gradovi.addLast(noviGrad);
							}
						}
					} else {
						jtfNazivGrada.setText("GRESKA");
						jtfBrojStanovnika.setText("GRESKA");
					}
				} catch (Exception ex) {
					jtfNazivGrada.setText("GRESKA");
					jtfBrojStanovnika.setText("GRESKA");
				}
			}
		});
		btnDodaj.setBounds(28, 99, 117, 29);
		contentPane.add(btnDodaj);
		
		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ObjectOutputStream maliGradoviOut = new ObjectOutputStream(
							new BufferedOutputStream(
									new FileOutputStream("mali_gradovi.out")));
					
					ObjectOutputStream srednjiGradoviOut = new ObjectOutputStream(
							new BufferedOutputStream(
									new FileOutputStream("srednji_gradovi.out")));
					
					ObjectOutputStream velikiGradoviOut = new ObjectOutputStream(
							new BufferedOutputStream(
									new FileOutputStream("veliki_gradovi.out")));

					for (int i = 0; i < gradovi.size(); i++) {
						
						if (gradovi.get(i).getBrojStanovnika() < 100000) {
							maliGradoviOut.writeObject(gradovi.get(i));
						} else if (gradovi.get(i).getBrojStanovnika() < 1000000) {
							srednjiGradoviOut.writeObject(gradovi.get(i));
						} else {
							velikiGradoviOut.writeObject(gradovi.get(i));
						}
					}
					maliGradoviOut.close();
					srednjiGradoviOut.close();
					velikiGradoviOut.close();
				} catch (Exception ex) {
					System.out.println("Greska: " + ex.getMessage());
				}
			}
		});
		btnSacuvaj.setBounds(157, 99, 117, 29);
		contentPane.add(btnSacuvaj);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtfNazivGrada.setText(null);
				jtfBrojStanovnika.setText(null);
			}
		});
		btnObrisi.setBounds(286, 99, 117, 29);
		contentPane.add(btnObrisi);
		
		jtfNazivGrada = new JTextField();
		jtfNazivGrada.setBounds(28, 47, 134, 28);
		contentPane.add(jtfNazivGrada);
		jtfNazivGrada.setColumns(10);
		
		jtfBrojStanovnika = new JTextField();
		jtfBrojStanovnika.setBounds(230, 47, 134, 28);
		contentPane.add(jtfBrojStanovnika);
		jtfBrojStanovnika.setColumns(10);
	}
}
