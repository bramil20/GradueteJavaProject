
public class VaterpolistaException extends RuntimeException {

	public VaterpolistaException(String message) {
		super(message);
	}
}
