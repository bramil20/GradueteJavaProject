
public class Vaterpolista {

	private String imePrezime;
	private String klub;
	private int poeni;

	public String getImePrezime() {
		return imePrezime;
	}

	public void setImePrezime(String imePrezime) {
		if (imePrezime == null || imePrezime.equals("")) {
			throw new VaterpolistaException("Ime i prezime ne mogu biti null, niti prazan string.");
		}
		this.imePrezime = imePrezime;
	}

	public String getKlub() {
		return klub;
	}

	public void setKlub(String klub) {
		if (klub == null || klub.equals("")) {
			throw new VaterpolistaException("Klub ne moze biti null, niti prazan string.");
		}
		this.klub = klub;
	}

	public int getPoeni() {
		return poeni;
	}

	public void setPoeni(int poeni) {
		if (poeni < 0) {
			throw new VaterpolistaException("Poeni ne mogu biti manji od nule.");
		}
		this.poeni = poeni;
	}
	
	@Override
	public String toString() {
		return "Ime i prezime: "+imePrezime+", klub: "+klub+", poeni: "+poeni;
	}

	@Override
	public boolean equals(Object obj) {
		Vaterpolista v = (Vaterpolista) obj;

		if (this.getImePrezime().equals(v.getImePrezime()) &&
				this.getKlub().equals(v.getKlub())) {
			return true;
		}
		return false;
	}
}
