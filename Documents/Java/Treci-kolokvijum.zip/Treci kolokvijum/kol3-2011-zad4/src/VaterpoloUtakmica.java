import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.LinkedList;

public class VaterpoloUtakmica {

	private LinkedList<Vaterpolista> vaterpolisti = new LinkedList<Vaterpolista>();

	public void upisiVaterpolisteSaMakarDvaGola() throws Exception {
		try {
			DataOutputStream out = new DataOutputStream(
										new BufferedOutputStream(
												new FileOutputStream("izvestaj.out")));

			for (int i = 0; i < vaterpolisti.size(); i++) {
				if (vaterpolisti.get(i).getPoeni() >= 2) {
					out.writeUTF(vaterpolisti.get(i).getImePrezime());
					out.writeUTF(vaterpolisti.get(i).getKlub());
					out.writeInt(vaterpolisti.get(i).getPoeni());
				}
			}
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}

	public void unesiNovogVaterpolistu(String imePrezime, String klub, int poeni) {
		Vaterpolista v = new Vaterpolista();
		v.setImePrezime(imePrezime);
		v.setKlub(klub);
		v.setPoeni(poeni);

		if (!vaterpolisti.contains(v)) {
			vaterpolisti.add(v);
		} else {
			try {
				PrintWriter out = new PrintWriter(
										new BufferedWriter(
											new FileWriter("greske.txt")));

				out.println(v);
				out.println("Vec postoji u listi");

				out.close();
			} catch (Exception e) {
				System.out.println("Greska: " + e.getMessage());
			}
		}
	}

	public void ucitajVaterpoliste() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
		for (int i = 0; i < 22; i++) {
			// Posto u slucaju greske, metoda treba da omoguci korisniku da nastavi 
			// unosenje ostalih vaterpolista, try/catch blok stavljamo unutar for petlje. 
			// U slucaju greske, ona ce biti uhvacena u catch bloku i petlja ce nastaviti. 
			try {
				System.out.print("Unesite ime i prezime: ");
				String imePrezime = br.readLine();

				System.out.print("Unesite klub: ");
				String klub = br.readLine();

				System.out.print("Unesite broj poena: ");
				int poeni = Integer.parseInt(br.readLine());

				Vaterpolista v = new Vaterpolista();
				v.setImePrezime(imePrezime);
				v.setKlub(klub);
				v.setPoeni(poeni);
				
				vaterpolisti.add(v);
			} catch (Exception e) {
				System.out.println("Greska: " + e.getMessage());
			}
		}
	}
}
