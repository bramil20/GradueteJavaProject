
public class StatistikaException extends Exception {

	public StatistikaException(String message) {
		super(message);
	}
}
