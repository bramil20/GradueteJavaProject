import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.LinkedList;

public class FudbalskaSezona {

	private LinkedList<Fudbaler> fudbaleri;
	
	public FudbalskaSezona() {
		fudbaleri = new LinkedList<Fudbaler>();
	}

	public void upisiRezerve() throws Exception {
		if (fudbaleri.isEmpty()) {
			throw new Exception("Nema unetih fudbalera");
		}
		
		try {
			PrintWriter out = new PrintWriter(
									new BufferedWriter(
											new FileWriter("rezerve.txt")));

			for (int i = 0; i < fudbaleri.size(); i++) {
				if (fudbaleri.get(i).getGolovi() == 0) {
					out.println(fudbaleri.get(i).getImePrezime());
				}
			}
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
	
	public void dodajFudbaleraSaTastature() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("Unesite ime i prezime: ");
			String imePrezime = br.readLine();

			System.out.print("Unesite poziciju: ");
			String pozicija = br.readLine();

			System.out.print("Unesite broj golova: ");
			int brojGolova = Integer.parseInt(br.readLine());

			Fudbaler noviFudbaler = new Fudbaler();
			noviFudbaler.setImePrezime(imePrezime);
			noviFudbaler.setPozicija(pozicija);
			noviFudbaler.setGolovi(brojGolova);

			if (!fudbaleri.contains(noviFudbaler)) {
				fudbaleri.add(noviFudbaler);
			}
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
	
	public void prethodnaIOvaSezona() {
		LinkedList<Fudbaler> prethodnaSezona = new LinkedList<Fudbaler>();
		
		// iscitavanje fudbalera iz prethodne sezone
		try {
			ObjectInputStream in = new ObjectInputStream(
					new FileInputStream("prethodna_sezona.out"));

			try {
				while (true) {
					Fudbaler o = (Fudbaler) (in.readObject());
					prethodnaSezona.add(o);
				}
			} catch (Exception e) {
			}

			in.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
		
		// uporedjivanje sa fudbalerima iz tekuce sezone
		for (int i = 0; i < fudbaleri.size(); i++) {
			for (int j = 0; j < prethodnaSezona.size(); j++) {
				
				if (fudbaleri.get(i).equals(prethodnaSezona.get(j)) && 
						fudbaleri.get(i).getGolovi() > 
							prethodnaSezona.get(j).getGolovi()) {
					System.out.println(fudbaleri.get(i).getImePrezime());
				}
			}
		}
		
		// drugi nacin
		for (int i = 0; i < prethodnaSezona.size(); i++) {
			Fudbaler fudbalerIzPrethodneSezone = prethodnaSezona.get(i);
			
			// proveravamo da li postoji fudbaler sa istim imenom u tekucoj sezoni. 
			// Obratiti paznju da metoda indexOf() interno poziva reimplementiranu metodu 
			// equals() klase Fudbaler
			int indexFudbalera = fudbaleri.indexOf(fudbalerIzPrethodneSezone);
			
			// ako je indexFudbalera -1, onda nije pronadjen u listi tekucih fudbalera
			if (indexFudbalera != -1) {
				Fudbaler fudbalerIzTekuceSezone = fudbaleri.get(indexFudbalera);
				
				if (fudbalerIzTekuceSezone.getGolovi() > fudbalerIzPrethodneSezone.getGolovi()) {
					System.out.println(fudbalerIzTekuceSezone.getImePrezime());
				}
			}
		}
	}
	
}
