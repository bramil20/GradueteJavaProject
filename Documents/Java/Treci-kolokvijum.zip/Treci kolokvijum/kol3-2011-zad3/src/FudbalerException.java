
public class FudbalerException extends RuntimeException {

	public FudbalerException(String message) {
		super(message);
	}
}
