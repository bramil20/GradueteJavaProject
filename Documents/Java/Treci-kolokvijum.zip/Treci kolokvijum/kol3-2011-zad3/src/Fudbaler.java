import java.io.Serializable;

public class Fudbaler implements Serializable {

	private String imePrezime;
	private String pozicija;
	private int golovi;

	public String getImePrezime() {
		return imePrezime;
	}

	public void setImePrezime(String imePrezime) {
		if (imePrezime == null || imePrezime.length() < 5) {
			throw new FudbalerException("Ime i prezime ne mogu biti null, niti kraci od 5 karaktera.");
		}
		this.imePrezime = imePrezime;
	}

	public String getPozicija() {
		return pozicija;
	}

	public void setPozicija(String pozicija) {
		if (pozicija == null || pozicija.equals("")) {
			throw new FudbalerException("Pozicija ne moze biti null, niti prazan string.");
		}
		this.pozicija = pozicija;
	}

	public int getGolovi() {
		return golovi;
	}

	public void setGolovi(int golovi) {
		if (golovi < 0) {
			throw new FudbalerException("Golovi ne mogu biti manji od nule.");
		}
		this.golovi = golovi;
	}

	@Override
	public boolean equals(Object obj) {
		// prvo proveravamo da li je prosledjeni objekat instanca klase Fudbaler
		if (!(obj instanceof Fudbaler)) {
			throw new FudbalerException("Ovo nije objekat klase Fudbaler");
		}
		
		Fudbaler ff = (Fudbaler) obj;

		if (this.getImePrezime().equals(ff.getImePrezime())) {
			return true;
		}
		return false;
	}
}
