
public class DemografijaException extends Exception {

	public DemografijaException(String message) {
		super(message);
	}
}
