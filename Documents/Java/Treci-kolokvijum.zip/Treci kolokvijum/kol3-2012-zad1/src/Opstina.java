public class Opstina {

	private String naziv;
	private int godinaPopisa;
	private int natalitet;
	private int mortalitet;

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		if (naziv == null || naziv.length() < 2) {
			throw new RuntimeException("Naziv ne moze biti null ili kraci od dva znaka.");
		}
		this.naziv = naziv;
	}

	public int getGodinaPopisa() {
		return godinaPopisa;
	}

	public void setGodinaPopisa(int godinaPopisa) {
		if (godinaPopisa < 0) {
			throw new RuntimeException("Godina ne moze biti manja od nule.");
		}
		this.godinaPopisa = godinaPopisa;
	}

	public int getNatalitet() {
		return natalitet;
	}

	public void setNatalitet(int natalitet) {
		if (natalitet < 0) {
			throw new RuntimeException("Natalitet ne moze biti manji od nule.");
		}
		this.natalitet = natalitet;
	}

	public int getMortalitet() {
		return mortalitet;
	}

	public void setMortalitet(int mortalitet) {
		if (mortalitet < 0) {
			throw new RuntimeException("Mortalitet ne moze biti manji od nule.");
		}
		this.mortalitet = mortalitet;
	}

	@Override
	public String toString() {
		return "Naziv opstine: "+naziv+"\n, godina popisa: "+godinaPopisa+"\n, natalitet: "+natalitet+"\n, mortalitet: "+mortalitet;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		// proveravamo da li je prosledjen objekat klase Opstina
		if (!(obj instanceof Opstina)) {
			throw new RuntimeException("Ovo nije objekat klase Opstina.");
		}
		
		Opstina opstina = (Opstina) obj;
		
		if (this.getNaziv().equals(opstina.getNaziv()) && 
				this.getGodinaPopisa() == opstina.getGodinaPopisa()) {
			return true;
		}
		return false;
	}
}
