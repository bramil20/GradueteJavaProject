import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.LinkedList;

public class Region {

	private LinkedList<Opstina> opstine;

	public Region() {
		opstine = new LinkedList<Opstina>();
	}

	public void unesiOstinu() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.print("Unesite naziv opstine: ");
			String naziv = br.readLine();

			System.out.print("Unesite godinu popisa: ");
			int godinaPopisa = Integer.parseInt(br.readLine());

			System.out.print("Unesite natalitet: ");
			int natalitet = Integer.parseInt(br.readLine());
			
			System.out.print("Unesite mortalitet: ");
			int mortalitet = Integer.parseInt(br.readLine());
			
			Opstina novaOpstina = new Opstina();
			novaOpstina.setNaziv(naziv);
			novaOpstina.setGodinaPopisa(godinaPopisa);
			novaOpstina.setNatalitet(natalitet);
			novaOpstina.setMortalitet(mortalitet);

			if (!opstine.contains(novaOpstina)) {
				opstine.add(novaOpstina);
			}
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
	
	public void upisiPodatkeZaGodinu(int godina) throws DemografijaException {
		if (godina < 0) {
			throw new DemografijaException("Prosledjena je pogresna vrednost za godinu.");
		}
		
		try {
			PrintWriter belaKugaWriter = new PrintWriter(
					new BufferedWriter(
							new FileWriter("bela_kuga.txt")));
			
			PrintWriter normalniPrirastWriter = new PrintWriter(
					new BufferedWriter(
							new FileWriter("normalni_prirast.txt")));
			
			
			for (int i = 0; i < opstine.size(); i++) {
				// posmatramo samo opstine sa popisom za prosledjenu godinu
				if (opstine.get(i).getGodinaPopisa() == godina) {
					
					// ako je mortalitet veci od nataliteta, upisujemo u fajl bela_kuga.txt
					if (opstine.get(i).getMortalitet() > opstine.get(i).getNatalitet()) {
						belaKugaWriter.println(opstine.get(i).toString());
					} 
					// ako je mortalitet manji od nataliteta, upisujemo u fajl normalni_prirast.txt
					else {
						normalniPrirastWriter.println(opstine.get(i));
					}
				}
			}

			// zatvaramo steam-ove
			belaKugaWriter.close();
			normalniPrirastWriter.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
	
	public void upisiPodatkeZaopstinu(String naziv) {
		try {
			DataOutputStream out = new DataOutputStream(
										new BufferedOutputStream(
												new FileOutputStream("opstina.out")));

			// ovde ce biti smestani popisi za datu opstinu sortirani u rastucem poretku po godini
			LinkedList<Opstina> popisiZaOpstinu = new LinkedList<Opstina>();
			
			for (int i = 0; i < opstine.size(); i++) {
				Opstina opstinaSaNajranijimPopisom = null;
				
				for (int j = 0; j < opstine.size(); j++) {
					if (opstine.get(j).getNaziv().equals(naziv)) {
						
						// ako opstinaSaNajranijimPopisom nije postavljena
						if (opstinaSaNajranijimPopisom == null) {
							opstinaSaNajranijimPopisom = opstine.get(j);
						} else{
							// ako smo naisli na opstinu sa manjom godinom popisa od opstinaSaNajranijimPopisom, a
							// koja se vec ne nalazi u listi
							if (opstinaSaNajranijimPopisom.getGodinaPopisa() > opstine.get(j).getGodinaPopisa()
									&& !popisiZaOpstinu.contains(opstinaSaNajranijimPopisom)) {
								opstinaSaNajranijimPopisom = opstine.get(j);
							}
						}
					}
				}
				
				popisiZaOpstinu.add(opstinaSaNajranijimPopisom);
			}

			// posto je lista sortirana, prolazimo kroz nju i redom upisujemo podatke 
			// o opstinama.
			for (int i = 0; i < popisiZaOpstinu.size(); i++) {
				out.writeUTF(popisiZaOpstinu.get(i).getNaziv());
				out.writeInt(popisiZaOpstinu.get(i).getGodinaPopisa());
				out.writeInt(popisiZaOpstinu.get(i).getNatalitet());
				out.writeInt(popisiZaOpstinu.get(i).getMortalitet());
			}
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
}
