
public class DemografijaException extends RuntimeException {

	public DemografijaException(String message) {
		super(message);
	}
}
