import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.LinkedList;

public class UniverzitetskeStatistike {

	private LinkedList<FakultetskeStatistike> fakulteti = new LinkedList<FakultetskeStatistike>();

	public void ucitajFakultete() {
		try {
			DataInputStream in = new DataInputStream(new BufferedInputStream(
					new FileInputStream("arhiva.out")));

			// prvo brisemo listu
			fakulteti.clear();

			while (in.available() != 0) {
				String naziv = in.readUTF();
				int godinaUpisa = in.readInt();
				int brojMesta = in.readInt();
				int brojPrijavljenih = in.readInt();

				FakultetskeStatistike fakultet = new FakultetskeStatistike();
				fakultet.setNaziv(naziv);
				fakultet.setGodinaUpisa(godinaUpisa);
				fakultet.setBrojMesta(brojMesta);
				fakultet.setBrojPrijavljenih(brojPrijavljenih);

				fakulteti.add(fakultet);
			}

			in.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}

	public void upisiPopularneFakultete() throws FakultetException {
		boolean postojePopularniFakulteti = false;
		
		try {
			ObjectOutputStream out = new ObjectOutputStream(
					new BufferedOutputStream(
							new FileOutputStream("popularni_fakulteti.out")));
			
			for (int i = 0; i < fakulteti.size(); i++) {
				if (fakulteti.get(i).getBrojPrijavljenih() > 2 * fakulteti.get(i).getBrojMesta()) {
					out.writeObject(fakulteti.get(i));
					postojePopularniFakulteti = true;
				}
			}

			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
		
		if (!postojePopularniFakulteti) {
			throw new FakultetException("Ne postoje popularni fakulteti.");
		}
	}
	
	public void upisiNajpopularnijeFakulteteZaGodine() {
		try {
			PrintWriter out = new PrintWriter(
					new BufferedWriter(
							new FileWriter("top_fakulteti.txt")));
			
			for (int god = 2010; god <= 2102; god++) {
				
				// Ne stavljamo da je najpopularniji fakultet onaj koji je prvi u listi posto ne mozemo reci 
				// da je ne znamo da li je on iz godine koju trazimo
				FakultetskeStatistike najpopularniji = null;
				double odnosNajpopularnijeg = 0;
				
				for (int j = 0; j < fakulteti.size(); j++) {
					if (fakulteti.get(j).getGodinaUpisa() == god) {
						// cast-ujemo u double da ne bismo imali celobrojno deljenje
						double odnos = (double) fakulteti.get(j).getBrojPrijavljenih() / fakulteti.get(j).getBrojMesta();

						// samo u prvoj iteraciji ce biti ispunjen uslov da je najpopularniji == null
						if (najpopularniji == null || odnos > odnosNajpopularnijeg) {
							najpopularniji = fakulteti.get(j);
							odnosNajpopularnijeg = odnos; 
						}
					}
				}
				
				out.println(najpopularniji);
			}
			
			out.close();
		} catch (Exception e) {
			System.out.println("Greska: " + e.getMessage());
		}
	}
}
