
public class FakultetException extends Exception {

	public FakultetException(String message) {
		super(message);
	}
}
