public class FakultetskeStatistike {

	private String naziv;
	private int godinaUpisa;
	private int brojMesta;
	private int brojPrijavljenih;

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		if (naziv == null || naziv.length() < 3) {
			throw new RuntimeException("Naziv ne moze biti null ili kraci od dva znaka.");
		}
		this.naziv = naziv;
	}

	public int getGodinaUpisa() {
		return godinaUpisa;
	}

	public void setGodinaUpisa(int godinaUpisa) {
		if (godinaUpisa <= 0) {
			throw new RuntimeException("Godina mora biti veca od nule.");
		}
		this.godinaUpisa = godinaUpisa;
	}

	public int getBrojMesta() {
		return brojMesta;
	}

	public void setBrojMesta(int brojMesta) {
		if (brojMesta <= 0) {
			throw new RuntimeException("Broj mesta mora biti veca od nule.");
		}
		this.brojMesta = brojMesta;
	}

	public int getBrojPrijavljenih() {
		return brojPrijavljenih;
	}

	public void setBrojPrijavljenih(int brojPrijavljenih) {
		if (brojPrijavljenih <= 0) {
			throw new RuntimeException("Broj prijavljenih mora biti veca od nule.");
		}
		this.brojPrijavljenih = brojPrijavljenih;
	}

	@Override
	public String toString() {
		return "Naziv: "+naziv+"\n, godina upisa: "+godinaUpisa+"\n, broj mesta: "+brojMesta+"\n, broj prijavljenih: "+brojPrijavljenih;
	}
	
	@Override
	public boolean equals(Object obj) {
		FakultetskeStatistike fs = (FakultetskeStatistike) obj;
		
		if (this.getNaziv().equals(fs.getNaziv()) && 
				this.getGodinaUpisa() == fs.getGodinaUpisa()) {
			return true;
		}
		return false;
	}
}
