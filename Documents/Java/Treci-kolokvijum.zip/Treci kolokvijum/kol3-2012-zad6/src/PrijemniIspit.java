import java.io.Serializable;

public class PrijemniIspit implements Serializable {

	private String nazivUstanove;
	private int godinaUpisa;
	private int brojMesta;
	private int brojPrijavljenih;

	public String getNazivUstanove() {
		return nazivUstanove;
	}

	public void setNazivnUstanove(String nazivUstanove) {
		if (nazivUstanove == null || nazivUstanove.length() < 5) {
			throw new PrijemniException("Naziv ustanove ne moze biti null ili kraci od pet znakova.");
		}
		this.nazivUstanove = nazivUstanove;
	}

	public int getGodinaUpisa() {
		return godinaUpisa;
	}

	public void setGodinaUpisa(int godinaUpisa) {
		if (godinaUpisa <= 0) {
			throw new PrijemniException("Godina upisa mora biti veca od nule.");
		}
		this.godinaUpisa = godinaUpisa;
	}

	public int getBrojMesta() {
		return brojMesta;
	}

	public void setBrojMesta(int brojMesta) {
		if (brojMesta <= 0) {
			throw new PrijemniException("Broj mesta mora biti veci od nule.");
		}
		this.brojMesta = brojMesta;
	}

	public int getBrojPrijavljenih() {
		return brojPrijavljenih;
	}

	public void setBrojPrijavljenih(int brojPrijavljenih) {
		if (brojPrijavljenih <= 0) {
			throw new PrijemniException("Broj prijavljenih mora biti veci od nule.");
		}
		this.brojPrijavljenih = brojPrijavljenih;
	}

	@Override
	public String toString() {
		// cast-ujemo u double da bismo izbegli celobrojno deljenje
		double odnos = (double) brojPrijavljenih / brojMesta;
		
		return "Naziv ustanove: "+nazivUstanove+", godina upisa: "+godinaUpisa+", broj mesta: "+brojMesta+
				", broj prijavljenih: "+brojPrijavljenih+", odnos prijavljenih i broja mesta je: "+odnos;
	}
	
}
