import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class PrijemniGUI extends JFrame {

	private JPanel contentPane;
	
	private JTextField jtfNaziv;
	private JTextField jtfGodina;
	private JTextField jtfBrojMesta;
	private JTextField jtfBrojPrijavljenih;

	private LinkedList<PrijemniIspit> ustanove = new LinkedList<PrijemniIspit>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrijemniGUI frame = new PrijemniGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PrijemniGUI() {
		setTitle("Prijemni ispit");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 530, 357);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(100, 120));
		contentPane.add(panel, BorderLayout.NORTH);
		
		final JTextArea textArea = new JTextArea();
		contentPane.add(textArea, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNaziv = new JLabel("Naziv");
		lblNaziv.setBounds(16, 6, 61, 16);
		panel.add(lblNaziv);
		
		jtfNaziv = new JTextField();
		jtfNaziv.setBounds(15, 26, 134, 20);
		panel.add(jtfNaziv);
		jtfNaziv.setColumns(10);
		
		JLabel lblGodinaUpisa = new JLabel("Godina upisa:");
		lblGodinaUpisa.setBounds(16, 66, 134, 16);
		panel.add(lblGodinaUpisa);
		
		jtfGodina = new JTextField();
		jtfGodina.setColumns(10);
		jtfGodina.setBounds(15, 86, 134, 20);
		panel.add(jtfGodina);
		
		JLabel lblBrojMesta = new JLabel("Broj mesta");
		lblBrojMesta.setBounds(180, 6, 108, 16);
		panel.add(lblBrojMesta);
		
		JLabel lblBrojPrijavljenih = new JLabel("Broj prijavljenih");
		lblBrojPrijavljenih.setBounds(180, 66, 114, 16);
		panel.add(lblBrojPrijavljenih);
		
		jtfBrojMesta = new JTextField();
		jtfBrojMesta.setColumns(10);
		jtfBrojMesta.setBounds(180, 26, 134, 20);
		panel.add(jtfBrojMesta);
		
		jtfBrojPrijavljenih = new JTextField();
		jtfBrojPrijavljenih.setColumns(10);
		jtfBrojPrijavljenih.setBounds(180, 86, 134, 20);
		panel.add(jtfBrojPrijavljenih);
		
		JButton btnUcitaj = new JButton("Ucitaj");
		btnUcitaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nazivFajla = textArea.getText();
				
				try{
					ObjectInputStream in = new ObjectInputStream(
							new FileInputStream(nazivFajla));
					try {
						while (true) {
							PrijemniIspit p = (PrijemniIspit) (in.readObject());
							
							if (p.getBrojPrijavljenih() > 0) {
								ustanove.add(p);
							}
						}
					} catch (Exception ex) {
					}

					// zatvaramo stream
					in.close();
				} catch (Exception ex) {
					System.out.println("Greska: " + ex.getMessage());
				}
			}
		});
		btnUcitaj.setBounds(351, 17, 117, 29);
		panel.add(btnUcitaj);
		
		JButton btnIspisi = new JButton("Ispisi");
		btnIspisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String textEditora = "";
				
				for (int i = 0; i < ustanove.size(); i++) {
					
					// ako se podaci o prijemnom ispitu odnose na godinu 2011
					if (ustanove.get(i).getGodinaUpisa() == 2011) {
						
						// pronalazimo da li postoje u listi podaci prijemnog ispita za istu ustanovu (ustanovu 
						// sa istim nazivom) koji se odnose na 2012 godinu i proveravamo da li je broj prijavljenih
						// u 2012 (na poziciji 'j') veci od broja prijavljenih u 2011 (na poziciji 'i')
						for (int j = 0; j < ustanove.size(); j++) {
							if (ustanove.get(i).getNazivUstanove().equals(ustanove.get(j).getNazivUstanove()) &&
									ustanove.get(j).getGodinaUpisa() == 2012 &&
									ustanove.get(i).getBrojPrijavljenih() < ustanove.get(j).getBrojPrijavljenih()) {
								
								textEditora += ustanove.get(i).getNazivUstanove() + "\n";
							}
						}
					}
				}
				
				textArea.setText(textEditora);
			}
		});
		btnIspisi.setBounds(351, 50, 117, 29);
		panel.add(btnIspisi);
		
		JButton btnIzadji = new JButton("Izadji");
		btnIzadji.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnIzadji.setBounds(351, 83, 117, 29);
		panel.add(btnIzadji);
	}
}
