
public class PrijemniException extends RuntimeException {

	public PrijemniException(String message) {
		super(message);
	}
}
