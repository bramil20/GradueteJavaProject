
public class VaterpoloKlubException extends RuntimeException {

	public VaterpoloKlubException(String message) {
		super(message);
	}
}
