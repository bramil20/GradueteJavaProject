
public class Vaterpolista {

	private String imePrezime;
	private String pozicija;
	private int poeni;

	public String getImePrezime() {
		return imePrezime;
	}

	public void setImePrezime(String imePrezime) {
		if (imePrezime == null || imePrezime.equals("")) {
			throw new VaterpoloKlubException("Ime i prezime ne mogu biti null, niti prazan string.");
		}
		this.imePrezime = imePrezime;
	}

	public String getPozicija() {
		return pozicija;
	}

	public void setPozicija(String pozicija) {
		if (pozicija == null || pozicija.equals("")) {
			throw new VaterpoloKlubException("Pozicija ne moze biti null, niti prazan string.");
		}
		this.pozicija = pozicija;
	}

	public int getPoeni() {
		return poeni;
	}

	public void setPoeni(int poeni) {
		if (poeni < 0) {
			throw new VaterpoloKlubException("Poeni ne mogu biti manji od nule.");
		}
		this.poeni = poeni;
	}
	
	@Override
	public boolean equals(Object obj) {
		// prvo proveravamo da li je prosledjeni objekat instanca klase Vaterpolista
		if (!(obj instanceof Vaterpolista)) {
			throw new VaterpoloKlubException("Ovo nije objekat klase Vaterpolista.");
		}
				
		Vaterpolista v = (Vaterpolista) obj;

		if (this.getImePrezime().equals(v.getImePrezime())) {
			return true;
		}
		return false;
	}
}
