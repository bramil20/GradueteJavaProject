import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class VaterpoloKlubGUI extends JFrame {

	private JPanel contentPane;
	private JTextField jtfImeIPrezime;
	private JTextField jtfPoeni;
	
	private LinkedList<Vaterpolista> igraci = new LinkedList<Vaterpolista>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VaterpoloKlubGUI frame = new VaterpoloKlubGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VaterpoloKlubGUI() {
		setResizable(false);
		setTitle("Vaterpolo klub");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 303, 184);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblImeIPrezime = new JLabel("Ime i prezime:");
		lblImeIPrezime.setBounds(18, 16, 107, 16);
		contentPane.add(lblImeIPrezime);
		
		JLabel lblPozicija = new JLabel("Pozicija:");
		lblPozicija.setBounds(18, 44, 107, 16);
		contentPane.add(lblPozicija);
		
		JLabel lblPoeni = new JLabel("Poeni:");
		lblPoeni.setBounds(18, 72, 107, 16);
		contentPane.add(lblPoeni);
		
		jtfImeIPrezime = new JTextField();
		jtfImeIPrezime.setBounds(137, 10, 134, 28);
		contentPane.add(jtfImeIPrezime);
		jtfImeIPrezime.setColumns(10);
		
		final JComboBox jcbPozicija = new JComboBox();
		jcbPozicija.setBounds(137, 40, 134, 27);
		jcbPozicija.addItem("golman");
		jcbPozicija.addItem("krilo");
		jcbPozicija.addItem("bek");
		jcbPozicija.addItem("sidro");
		jcbPozicija.addItem("centar");
		contentPane.add(jcbPozicija);
		
		jtfPoeni = new JTextField();
		jtfPoeni.setBounds(137, 66, 134, 28);
		contentPane.add(jtfPoeni);
		jtfPoeni.setColumns(10);
		
		JButton btnUnesi = new JButton("Unesi");
		btnUnesi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String imePrezime = jtfImeIPrezime.getText();
					String pozicija = jcbPozicija.getSelectedItem().toString();
					int poeni = Integer.parseInt(jtfPoeni.getText());

					Vaterpolista noviVaterpolista = new Vaterpolista();
					noviVaterpolista.setImePrezime(imePrezime);
					noviVaterpolista.setPozicija(pozicija);
					noviVaterpolista.setPoeni(poeni);
					
					// ako ovakav igrac vec ne postoji u listi
					if (!igraci.contains(noviVaterpolista)) {
						
						// ovaj uslov je zadovoljen kada unosimo prvog igraca
						if (igraci.isEmpty()) {
							igraci.add(noviVaterpolista);
						} else {
							// promenljiva 'unesen' nam sluzi kao indikator da je igrac vec unesen.
							boolean unesen = false;
							
							for (int j = 0; j < igraci.size(); j++) {
								if (igraci.get(j).getPoeni() < noviVaterpolista.getPoeni()) {
									igraci.add(j, noviVaterpolista);
									unesen = true;
									break;
								}
							}
							
							// Ukoliko svi igraci u listi imaju broj poena koji je veci od broja poena igraca kojeg
							// unosimo, uslov u prethodnoj petlji nece nijednom biti ispunjen i vrednost promenljive 
							// 'unesen' ce ostati false, odnosno oznacavace da igrac jos nije unesen. U tom slucaju, 
							// igraca treba uneti na kraj liste.
							if (!unesen) {
								igraci.addLast(noviVaterpolista);
							}
						}
					} else {
						setTitle(getTitle() + "GRESKA");
					}
				} catch (Exception ex) {
					setTitle(getTitle() + "GRESKA");
				}
			}
		});
		btnUnesi.setBounds(18, 118, 79, 29);
		contentPane.add(btnUnesi);
		
		JButton btnSacuvaj = new JButton("Sacuvaj");
		btnSacuvaj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					DataOutputStream golmaniOut = new DataOutputStream(
							new BufferedOutputStream(
									new FileOutputStream("golmani.out")));
					
					DataOutputStream igraciOut = new DataOutputStream(
							new BufferedOutputStream(
									new FileOutputStream("igraci.out")));
					
					for (int i = 0; i < igraci.size(); i++) {
						if (igraci.get(i).getPozicija().equals("golman")) {
							golmaniOut.writeUTF(igraci.get(i).getImePrezime());
							golmaniOut.writeChar('\t');
							golmaniOut.writeUTF(igraci.get(i).getPozicija());
							golmaniOut.writeChar('\t');
							golmaniOut.writeInt(igraci.get(i).getPoeni());
							golmaniOut.writeChar('\n');
						} else {
							igraciOut.writeUTF(igraci.get(i).getImePrezime());
							igraciOut.writeChar('\t');
							igraciOut.writeUTF(igraci.get(i).getPozicija());
							igraciOut.writeChar('\t');
							igraciOut.writeInt(igraci.get(i).getPoeni());
							igraciOut.writeChar('\n');
						}
					}
					
					// zatvaramo stream-ove
					golmaniOut.close();
					igraciOut.close();
				} catch (Exception ex) {
					System.out.println("Greska: " + ex.getMessage());
				}
			}
		});
		btnSacuvaj.setBounds(109, 118, 79, 29);
		contentPane.add(btnSacuvaj);
		
		JButton btnObrisi = new JButton("Obrisi");
		btnObrisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtfImeIPrezime.setText(null);
				jtfPoeni.setText(null);
			}
		});
		btnObrisi.setBounds(200, 118, 79, 29);
		contentPane.add(btnObrisi);
	}
}
