package autobuska_stanica;

import autobuska_stanica.rezervacije.RezervacijaKarata;

public class AutobuskaStanica implements RezervacijaKarata {
	private Polazak[] polasci = new Polazak[100];

	public void unesiPolazak(Polazak polazakZaUnos) {

		if (polazakZaUnos != null ){
			System.out.println("Greska: Polazak ne sme biti null");
			return;
		}

		boolean unet = false;
		for (int i = 0; i < polasci.length; i++) {
			if (polasci[i] == null) {
				polasci[i] = polazakZaUnos;
				unet = true;
				break;
			}
		}
		
		if (!unet)
			System.out.println("Greska: Niz je pun!");

		
		
	}

	
	@Override
	public boolean rezervisiKarte(String destinacija, int brojKarata) {
	
		for(int i=1; i<polasci.length; i++) {
			if ((polasci[i].getDestinacija().equals(destinacija)) &&
				((polasci[i].getBrojSlobodnihMesta()-brojKarata)>=0)) {
				
				int brojSlobodnihMesta = polasci[i].getBrojSlobodnihMesta(); 
				polasci[i].setBrojSlobodnihMesta(brojSlobodnihMesta-brojKarata);
				return true;
			}
		}
		
		return false;
	}

	@Override
	public void proslediRezervaciju(RezervacijaKarata[] stanice,
			String destinacija, int brojKarata) {
		boolean statusRezervacije = false;
		for(int i=0; i<stanice.length; i++) {
			statusRezervacije = stanice[i].rezervisiKarte(destinacija, brojKarata);
			if (statusRezervacije == true) {
				System.out.println("Rezervacija uspela!");
				break;
			} else {
				System.out.println("Rezervacija nije uspela, pokusacu na sledecoj stanici!");
			}
		}
		
		if (statusRezervacije == false) {
			System.out.println("Nigde nema dovoljno mesta za zadatu destinaciju!");
		}

	}

}