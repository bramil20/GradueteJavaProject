package autobuska_stanica.rezervacije;

public interface RezervacijaKarata {
	public boolean rezervisiKarte(String destinacija, int brojKarata);
	public void proslediRezervaciju(RezervacijaKarata[] stanice, String destinacija, int brojKarata);
}
