package autobuska_stanica;

import java.util.GregorianCalendar;

public class Polazak {
	private String destinacija;
	private GregorianCalendar vreme;
	private int brojSlobodnihMesta;
	
	public String getDestinacija() {
		return destinacija;
	} 
	
	public void setDestinacija(String destinacija) {
		if ((destinacija==null) || (destinacija.isEmpty())) {
			System.out.println("Greska: Destinacija ne sme biti null ili prazan string!");
		} else {
			this.destinacija = destinacija;
		}
	}
	
	public GregorianCalendar getVreme() {
		return vreme;
	}
	
	public void setVreme(GregorianCalendar vreme) {
		if ((vreme==null) || (vreme.before(new GregorianCalendar()))) {
			System.out.println("Greska: Vreme ne sme biti null ili trenutak u proslosti!");
		} else {
			this.vreme = vreme;
		}
	}
	
	public int getBrojSlobodnihMesta() {
		return brojSlobodnihMesta;
	}
	
	public void setBrojSlobodnihMesta(int brojSlobodnihMesta) {
		if (brojSlobodnihMesta < 0) {
			System.out.println("Greska: Broj slobodnih mesta ne sme biti negativan broj!!");
		} else {
			this.brojSlobodnihMesta = brojSlobodnihMesta;
		}
	}

	@Override
	public String toString() {
		return "Destinacija: " + destinacija + " Vreme:" + vreme
				+ ", Broj mesta=" + brojSlobodnihMesta;
	}
	
	

	
	
}
