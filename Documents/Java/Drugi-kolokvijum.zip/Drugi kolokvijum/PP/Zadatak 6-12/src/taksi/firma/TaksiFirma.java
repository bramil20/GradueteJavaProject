package taksi.firma;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import taksi.TaksiCentrala;
import taksi.TaksiVozilo;

public class TaksiFirma implements TaksiCentrala {
	private LinkedList<TaksiVozilo> vozila = new LinkedList<TaksiVozilo>();

	public void unesiTaksistu(TaksiVozilo vozilo) {
		vozila.addLast(vozilo);
		vozilo.setBrojPoziva(0);
		vozilo.setSlobodan(true);
	}

	@Override
	public void primiPoziv(int taksiBroj, String imeVozaca, String prezimeVozaca) {
		String id = taksiBroj + " " + imeVozaca + " " + prezimeVozaca;
		boolean nadjen = false;

		for (int i = 0; i < vozila.size(); i++) {
			TaksiVozilo vozilo = vozila.get(i);
			if (vozilo.getId().equals(id)) {
				if (vozilo.getKrajSmene().after(new GregorianCalendar())) {					
					int brojPoziva = vozilo.getBrojPoziva();
					vozilo.setBrojPoziva(brojPoziva + 1);
					vozilo.setSlobodan(false);
					nadjen = true;
				} else {
					System.out.println("Trazeno vozilo je zavrsilo smenu");
				}
			}
		}

		if (!nadjen)
			System.out.println("Taksi nije nadjen!");

	}

	@Override
	public void uredi() {
		for(int i=0; i<vozila.size(); i++) {
			TaksiVozilo vozilo=vozila.get(i);
			if (vozilo.isSlobodan()) {
				vozila.remove(i);
				vozila.addFirst(vozilo);
			}
		}		
	}

}
