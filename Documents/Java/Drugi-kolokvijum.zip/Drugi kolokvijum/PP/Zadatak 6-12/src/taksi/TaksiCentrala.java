package taksi;

public interface TaksiCentrala {
	public void primiPoziv(int taksiBroj, String imeVozaca, String prezimeVozaca);
	public void uredi();
}
