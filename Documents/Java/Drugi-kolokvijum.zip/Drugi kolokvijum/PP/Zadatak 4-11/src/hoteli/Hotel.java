package hoteli;

public class Hotel {
	private String naziv;
	private String regija;
	private int brojZvezdica;
	private int ocena;
	
	public String getNaziv() {
		return naziv;
	}
	
	public void setNaziv(String naziv) {
		if ((naziv == null) || (naziv.isEmpty())) {
			System.out.println("Greska: Naziv ne sme biti null ili prazan string!");
		} else {
			this.naziv = naziv;
		}
	}
	
	public String getRegija() {
		return regija;
	}
	
	public void setRegija(String regija) {
		if ((regija == null) || (regija.isEmpty())) {
			System.out.println("Greska: Regija ne sme biti null ili prazan string!");
		} else {
			this.regija = regija;
		}		
	}
	
	public int getBrojZvezdica() {
		return brojZvezdica;
	}
	
	public void setBrojZvezdica(int brojZvezdica) {
		if ((brojZvezdica<1) || (brojZvezdica>5)) {
			System.out.println("Greska: Broj zvezdica mora biti izmedju 1 i 5");
		} else {
			this.brojZvezdica = brojZvezdica;
		}		
	}
	
	public int getOcena() {
		return ocena;
	}
	
	public void setOcena(int ocena) {
		if ((ocena<1) || (ocena>5)) {
			System.out.println("Greska: Ocena mora biti izmedju 1 i 5");
		} else {
			this.ocena = ocena;
		}		
	}
	
	
	
}
