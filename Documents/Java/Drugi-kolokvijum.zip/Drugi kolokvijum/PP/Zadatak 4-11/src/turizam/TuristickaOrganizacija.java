package turizam;

import hoteli.Hotel;
import java.util.GregorianCalendar;
import java.util.LinkedList;

import regija.PonudaRegije;

public class TuristickaOrganizacija implements PonudaRegije {
	private LinkedList<Hotel> hoteli;
	private GregorianCalendar poslednjaIzmena;
	
	public TuristickaOrganizacija() {
		hoteli = new LinkedList<Hotel>();
	}
	
	public void unesiHotel(Hotel hotel) {
		if (hotel == null) {
			System.out.println("Greska: Hotel ne sme biti null!");
			return;
		}
		
		if (hoteli.contains(hotel)) {
			System.out.println("Greska: Hotel se vec nalazi u listi");
			return;			
		}
		
		hoteli.addFirst(hotel);
		poslednjaIzmena = new GregorianCalendar();
	}

	@Override
	public void napraviTopPonudu(String nazivRegije) {
		System.out.println("Regija: "+nazivRegije + " Poslednja izmena: "+poslednjaIzmena);
		
		for(int i=0; i<hoteli.size(); i++) {
			Hotel hotel=hoteli.get(i);
			if ((hotel.getRegija().equals(nazivRegije)) && 
				(hotel.getBrojZvezdica()==5) &&
				(hotel.getOcena()==5)) {
				System.out.println(hotel.getNaziv());
			}
		}
		
	}

	@Override
	public LinkedList<Hotel> napraviTopPonudu(String nazivRegije, int brojZvezdica) {
		LinkedList<Hotel> topLista = new LinkedList<Hotel>();
		int brojHotela=0;
		int ocena = 5;
		
		while(ocena>0) {			
			for(int i=0; i<hoteli.size(); i++){
				Hotel hotel = hoteli.get(i);
				if ((hotel.getRegija().equals(nazivRegije)) && 
					(hotel.getBrojZvezdica() == brojZvezdica) &&
					(hotel.getOcena() == ocena)) {
						topLista.add(hotel);
						brojHotela++;
				}
				
				if (brojHotela==5) {
					return topLista;
				}
			}
			ocena--;
		}				
		return topLista;
	}

}
