package regija;

import hoteli.Hotel;

import java.util.LinkedList;

public interface PonudaRegije {
	public void napraviTopPonudu(String nazivRegije);
	public LinkedList<Hotel> napraviTopPonudu(String nazivRegija, int brojZvezdica);
}
