package racunari.igraonica;

import racunari.centar.RacunarskiCentar;
import racunari.domen.Racunar;

public class Igraonica implements RacunarskiCentar {
	public Racunar[] racunari;
	
	public Igraonica(int kapacitet) {
		if (kapacitet>0)
			racunari=new Racunar[kapacitet];
		else
			racunari=new Racunar[20];
	}
	
	@Override
	public int vratiBrojIgrackihKonfiguracija(double takt, int memorija) {
		int brojKonfiguracija=0;
		
		for(int i=0; i<racunari.length; i++) {
			if ((racunari[i].getTakt()>=takt) && (racunari[i].getMemorija()>=memorija)) 
				brojKonfiguracija++;			
		}
				
		return brojKonfiguracija;
	}

	public void unesiRacunar(Racunar racunar) {
		if (racunar==null) {
			System.out.println("NULL objekat");
			return;
		}
		
		boolean unet=false;
		for(int i=racunari.length-1; i>=0; i--) {
			if (racunari[i]==null) {
				racunari[i]=racunar;
				unet=true;
				break;
			}
		}
		
		if (!unet)
			System.out.println("Niz je pun");	
		
	}

	@Override
	public boolean proveriKapacitet(RacunarskiCentar[] centri, int brojUcesnika) {
		// TODO: ovde je greska u tekstu zadatka trab da se prosledjuju takt i memorija kako zna da je igracka konf 
		for(int i=0; i<centri.length; i++) {
			if (centri[i].vratiBrojIgrackihKonfiguracija(takt, memorija)>=brojUcesnika)
				return true;
		}
		
		return false;
	}	
	
}
