package racunari.centar;

public interface RacunarskiCentar {
	public int vratiBrojIgrackihKonfiguracija(double takt, int memorija);
	public boolean proveriKapacitet(RacunarskiCentar[] centri , int brojUcesnika);
}
