package racunari.domen;

import java.util.GregorianCalendar;

public class Racunar {
	private String procesor;
	private double takt;
	private int memorija;
	private GregorianCalendar datumNabavke;
	
	public String getProcesor() {
		return procesor;
	}
	
	public void setProcesor(String procesor) {
		if ((procesor==null) || (procesor.length()<3))
			System.out.println("Greska: Procesor ne sme biti null ili string kraci od 3 znaka!");
		else 
			this.procesor = procesor;
	}
	
	public double getTakt() {
		return takt;
	}
	
	public void setTakt(double takt) {
		if (takt<=0) 
			System.out.println("Greska: Takt mora biti veci od nule!");
		else
			this.takt = takt;
	}
	
	public int getMemorija() {
		return memorija;
	}
	
	public void setMemorija(int memorija) {
		if (memorija<=0) 
			System.out.println("Greska: Memorija mora biti veca od nule!");
		else
			this.memorija = memorija;
	}
	
	public GregorianCalendar getDatumNabavke() {
		return datumNabavke;
	}
	
	public void setDatumNabavke(GregorianCalendar datumNabavke) {
		if ((datumNabavke==null) || (!datumNabavke.before(new GregorianCalendar())))
			System.out.println("Greska: Datum nabavke ne sme biti null, i mora biti trenutak iz proslosti");
		else 
			this.datumNabavke = datumNabavke;
	}

	@Override
	public String toString() {
		return "Racunar [procesor=" + procesor + ", takt=" + takt
				+ ", memorija=" + memorija + ", datumNabavke=" + datumNabavke
				+ "]";
	}
	
	
	
}
