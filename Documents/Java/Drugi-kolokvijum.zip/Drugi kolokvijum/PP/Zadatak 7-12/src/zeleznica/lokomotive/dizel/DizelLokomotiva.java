package zeleznica.lokomotive.dizel;

import zeleznica.lokomotive.Lokomotiva;

public class DizelLokomotiva extends Lokomotiva {
	private int potrosnja;
	
	public int getPotrosnja() {
		return potrosnja;
	}

	public void setPotrosnja(int potrosnja) {
		this.potrosnja = potrosnja;
	}

	@Override
	public void ispisi() {
		System.out.println("Naziv: "+getNaziv()+
							" Datum proizvodnje:"+getDatumProizvodnje()+
							" Datum rashodovanja: "+getDatumRashodovanja()+
							" Nosivost: "+getNosivost()+
							" Potrosnja: "+getPotrosnja());		
	}
	
}
