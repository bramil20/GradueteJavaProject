package zeleznica.lokomotive.elektricne;

import zeleznica.lokomotive.Lokomotiva;

public class ElektricnaLokomotiva extends Lokomotiva {

	@Override
	public void ispisi() {
		System.out.println("Naziv: "+getNaziv()+
							" Datum proizvodnje:"+getDatumProizvodnje()+
							" Datum rashodovanja: "+getDatumRashodovanja()+
							" Nosivost: "+getNosivost());		
	}
	

}
