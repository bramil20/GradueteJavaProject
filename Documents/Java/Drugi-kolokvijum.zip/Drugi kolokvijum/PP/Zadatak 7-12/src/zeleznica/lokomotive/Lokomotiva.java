package zeleznica.lokomotive;

import java.util.GregorianCalendar;

public abstract class Lokomotiva {
	private String naziv="nepoznat";
	private GregorianCalendar datumProizvodnje;
	private GregorianCalendar datumRashodovanja;
	private int nosivost;
	
	public String getNaziv() {
		return naziv;
	}
	
	public void setNaziv(String naziv) {
		if (naziv==null)
			System.out.println("Greska: Naziv ne sme biti null");
		else
			this.naziv = naziv;
	}
	
	public GregorianCalendar getDatumProizvodnje() {
		return datumProizvodnje;
	}
	
	public void setDatumProizvodnje(GregorianCalendar datumProizvodnje) {
		if (!datumProizvodnje.before(new GregorianCalendar()))
			System.out.println("Greska: datum proizvodnje mora biti trenutak u proslosti");
		else
			this.datumProizvodnje = datumProizvodnje;
	}
	
	public GregorianCalendar getDatumRashodovanja() {
		return datumRashodovanja;
	}
	
	public void setDatumRashodovanja(GregorianCalendar datumRashodovanja) {
		if (!datumRashodovanja.after(new GregorianCalendar()))
			System.out.println("Greska: datum rashodovanja mora biti trenutak u buducnosti!");
		else
			this.datumRashodovanja = datumRashodovanja;
	}
	
	public int getNosivost() {
		return nosivost;
	}
	
	public void setNosivost(int nosivost) {
		if (nosivost<=0)
			System.out.println("Greska: Nosivost mora biti veca od nule!");
		this.nosivost = nosivost;
	}
	
	public abstract void ispisi();	
}
