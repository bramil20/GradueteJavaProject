package zeleznica;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import zeleznica.lokomotive.Lokomotiva;
import zeleznica.lokomotive.dizel.DizelLokomotiva;
import zeleznica.lokomotive.elektricne.ElektricnaLokomotiva;

public class ZeleznickiDepo {
	private Lokomotiva[] lokomotive;

	public ZeleznickiDepo() {
		lokomotive = new Lokomotiva[50];
	}

	public void rashoduj() {
		GregorianCalendar sada = new GregorianCalendar();
	
		for (int i = 0; i < lokomotive.length; i++) {
			if (lokomotive[i] != null) {
				if (lokomotive[i].getDatumRashodovanja().before(sada)) {
					lokomotive[i].ispisi();
					lokomotive[i] = null;
				}
			}
		}
	}

	public void unesiLokomotivu(String naziv,
			GregorianCalendar datumProizvodnje,
			GregorianCalendar datumRashodovanja, int nosivost, int potrosnja) {
		Lokomotiva zaUnos;

		if (potrosnja > 0) {
			DizelLokomotiva dizel = new DizelLokomotiva();
			dizel.setNaziv(naziv);
			dizel.setDatumProizvodnje(datumProizvodnje);
			dizel.setDatumRashodovanja(datumRashodovanja);
			dizel.setNosivost(nosivost);
			dizel.setPotrosnja(potrosnja);
			zaUnos = dizel;
		} else {
			ElektricnaLokomotiva elektricna = new ElektricnaLokomotiva();
			elektricna.setNaziv(naziv);
			elektricna.setDatumProizvodnje(datumProizvodnje);
			elektricna.setDatumRashodovanja(datumRashodovanja);
			elektricna.setNosivost(nosivost);
			zaUnos = elektricna;
		}

		boolean uneta = false;

		for (int i = 0; i < lokomotive.length; i++) {
			if (lokomotive[i] == null) {
				lokomotive[i] = zaUnos;
				uneta = true;
			}
		}

		if (!uneta) {
			zaUnos.ispisi();
			System.out.println("Nema mesta za unos lokomotive!");
		}

	}

	public  LinkedList<DizelLokomotiva> vratiDveSaNajmanjomPotrosnjom() {
		LinkedList<DizelLokomotiva> dizelke=new LinkedList<DizelLokomotiva>();
				
		
		for(int i=0; i<lokomotive.length; i++ ) {
			if (lokomotive[i]==null) continue;
			if (lokomotive[i] instanceof DizelLokomotiva) {
				DizelLokomotiva dizelka =(DizelLokomotiva)lokomotive[i];
				if (dizelke.size()<2) {						
						dizelke.add(dizelka);
					} else {
						for(int j=0; j<dizelke.size(); j++) {
							if (  dizelka.getPotrosnja() < dizelke.get(j).getPotrosnja())
								dizelke.set(j, dizelka);
					}
				}
			}
		}	
		
		
		return dizelke;
	}
}
