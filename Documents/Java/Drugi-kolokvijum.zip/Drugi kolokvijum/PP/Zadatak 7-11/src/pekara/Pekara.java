package pekara;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import namirnice.Pecivo;
import namirnice.Pica;
import namirnice.Sendvic;

public class Pekara {
	private Pecivo[] ponuda;
	
	public Pekara() {
		ponuda = new Pecivo[100];
	}
	
	public double prosecnaKalorijskaVrednost() {
		double suma = 0;
		double brojPeciva=0;
		
		for(int i=0; i<ponuda.length; i++) {
			if (ponuda[i]!=null ) {
				suma+=ponuda[i].getKalorijskaVrednost();
				brojPeciva++;
			}
		}
		
		return suma/brojPeciva;
	}
	
	public void dodajSendvic(String naziv, double kalorijskaVrednost, GregorianCalendar rokTrajanja) {
		GregorianCalendar sada = new GregorianCalendar();
		
		if (rokTrajanja.after(sada)) {
			Sendvic sendvic = new Sendvic();
			sendvic.setNaziv(naziv);
			sendvic.setKalorijskaVrednost(kalorijskaVrednost);
			sendvic.setRokTrajanja(rokTrajanja);
			
			boolean unet=false;
			for(int i=0; i<ponuda.length; i++) {
				if (ponuda[i]==null) {
					ponuda[i]=sendvic;
					unet=true;
					break;
				}
			}
			
			if (!unet) {
				System.out.println("Greska: Nema mesta u nizu za unos sendvica!");
			}
		} else {
			System.out.println("Rok trajanja mora biti datum u buducnosti.");
		}
	}
	
	public LinkedList<Pica> vratiBajatePiceSaKulenom() {
		LinkedList<Pica> bajatePice=new LinkedList<Pica>();
		
		for(int i=0; i<ponuda.length; i++) {
			if (!(ponuda[i] instanceof Pica)) continue; 
			Pica pica = (Pica)ponuda[i];		

			if ((pica.getRokTrajanja().before(new GregorianCalendar())) &&
					(pica.getPrilozi().indexOf("kulen")!=-1)) {
				bajatePice.add((Pica) ponuda[i]);
			}
		}
		
		return bajatePice;
	}
	
	
}
