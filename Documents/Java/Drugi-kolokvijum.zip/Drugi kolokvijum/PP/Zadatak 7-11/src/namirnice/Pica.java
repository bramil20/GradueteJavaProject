package namirnice;

public class Pica extends Pecivo{
	private String prilozi;

	public String getPrilozi() {
		return prilozi;
	}

	public void setPrilozi(String prilozi) {
		this.prilozi = prilozi;
	}

	@Override
	public void prikazi() {
		System.out.println("Naziv: "+getNaziv()+" Kalorijska vrednost:"+getKalorijskaVrednost()+
				" Rok trajanja:"+getRokTrajanja()+ " Prilozi:"+prilozi+" Pecivo je pica");		
	}
	
	
}
