package namirnice;

import java.util.GregorianCalendar;

public abstract class Pecivo {
	private String naziv="NEPOZNAT";
	private double kalorijskaVrednost;
	private GregorianCalendar rokTrajanja;
	
	public String getNaziv() {
		return naziv;
	}
	
	public void setNaziv(String naziv) {
		if (naziv==null) 
			System.out.println("Greska: Naziv ne sme biti null!");
		else
			this.naziv = naziv;
	}
	
	public double getKalorijskaVrednost() {
		return kalorijskaVrednost;
	}
	
	public void setKalorijskaVrednost(double kalorijskaVrednost) {
		if (kalorijskaVrednost<=0)
			System.out.println("Greska: Kalorijska vrednost mora biti veca od nule!");
		else
			this.kalorijskaVrednost = kalorijskaVrednost;
	}
	
	public GregorianCalendar getRokTrajanja() {
		return rokTrajanja;
	}
	
	public void setRokTrajanja(GregorianCalendar rokTrajanja) {
		if ((rokTrajanja==null) || (!rokTrajanja.after(new GregorianCalendar())))
			System.out.println("Greska: Rok trajanja ne sme biti null i mora biti trenutak u buducnosti!");
		else
			this.rokTrajanja = rokTrajanja;
	}
	
	public abstract void prikazi();
	
	
}
