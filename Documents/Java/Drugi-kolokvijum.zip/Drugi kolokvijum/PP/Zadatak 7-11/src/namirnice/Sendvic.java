package namirnice;

public class Sendvic extends Pecivo {

	@Override
	public void prikazi() {
		System.out.println("Naziv: "+getNaziv()+" Kalorijska vrednost:"+getKalorijskaVrednost()+
							" Rok trajanja:"+getRokTrajanja()+ " Namirnica je sendvic");
	}

}
