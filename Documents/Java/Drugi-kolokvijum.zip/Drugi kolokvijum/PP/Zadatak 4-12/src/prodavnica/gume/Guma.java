package prodavnica.gume;

public class Guma {
	private String marka;
	private int sirina;
	private int visina;
	private int precnik;
	private int stanje;
	
	public String getMarka() {
		return marka;
	}
	
	public void setMarka(String marka) {
		if ((marka==null) || marka.isEmpty())
			System.out.println("Greska: Marka ne sme biti null ili prazan string");
		else
			this.marka = marka;
	}
	
	public int getSirina() {
		return sirina;
	}
	
	public void setSirina(int sirina) {
		if ((sirina<135) || (sirina>265)) 
			System.out.println("Greska: sirina nije u dozvoljenom intervalu");
		else
			this.sirina = sirina;
	}
	
	public int getVisina() {
		return visina;
	}
	
	public void setVisina(int visina) {
		if ((visina<45) || (visina>85)) 
			System.out.println("Greska: visina nije u dozvoljenom intervalu");
		else
			this.visina = visina;
	}
	
	public int getPrecnik() {
		return precnik;
	}
	
	public void setPrecnik(int precnik) {
		if ((precnik<13) || (precnik>19)) 
			System.out.println("Greska: precnik nije u dozvoljenom intervalu");
		else		
			this.precnik = precnik;
	}
	
	public int getStanje() {
		return stanje;
	}
	
	public void setStanje(int stanje) {
		if (stanje<0) 
			System.out.println("Greska: stanje mora bili nenegativna vrednost");
		else			
			this.stanje = stanje;
	}

	@Override
	public String toString() {
		return "Guma [marka=" + marka + ", sirina=" + sirina + ", visina="
				+ visina + ", precnik=" + precnik + ", stanje=" + stanje + "]";
	}
	
	
	
	
	
	
	
}
