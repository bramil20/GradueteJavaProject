package prodavnica.interfejs;

import prodavnica.gume.Guma;

public interface PretragaGuma { // TODO: dodati u tekst zadatka i marku
	public void pretrazi(String marka, int sirina, int visina, int precnik);
	public void pretraziLanacProdavnica(PretragaGuma[] prodavnice, Guma guma); 
}
