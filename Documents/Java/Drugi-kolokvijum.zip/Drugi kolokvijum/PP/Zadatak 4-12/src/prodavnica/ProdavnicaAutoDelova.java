package prodavnica;

import java.util.LinkedList;

import prodavnica.gume.Guma;
import prodavnica.interfejs.PretragaGuma;

public class ProdavnicaAutoDelova implements PretragaGuma {
	private LinkedList<Guma> ponudaGuma;
		
	public ProdavnicaAutoDelova() {
		ponudaGuma = new LinkedList<Guma>();
	}

	
	@Override
	public void pretrazi(String marka, int sirina, int visina, int precnik) {
		for(int i=0; i<ponudaGuma.size(); i++) {
			Guma guma = ponudaGuma.get(i);
			if (guma.getMarka().equals(marka) &&(guma.getSirina()==sirina) && (guma.getVisina()==visina) && (guma.getPrecnik()==precnik))
				System.out.println(guma);
		}		
	}
	
	public void unesiGumu(Guma guma) {
		boolean postojiUListi=false;
		
		for(int i=0; i<ponudaGuma.size(); i++) {
			Guma g = ponudaGuma.get(i);
			if ((g.getMarka().equals(guma.getMarka())) && 
					(g.getSirina()==guma.getSirina()) &&
					(g.getVisina()==guma.getSirina()) &&
					(g.getPrecnik()==guma.getPrecnik())) {
				postojiUListi = true;
				int postojeceStanje = g.getStanje();
				g.setStanje(postojeceStanje+guma.getStanje());
			}
		}
				
		if (!postojiUListi) { 
			ponudaGuma.add(guma);
		} 
	}

	@Override
	public void pretraziLanacProdavnica(PretragaGuma[] prodavnice, Guma guma) {
		for(int i=0; i<prodavnice.length; i++) {
			prodavnice[i].pretrazi(guma.getMarka(), guma.getSirina(), guma.getVisina(), guma.getPrecnik());
		}
		
	}
	
	
	
}
