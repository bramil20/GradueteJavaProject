package autobuska_stanica.dolasci;

import java.util.LinkedList;
import autobuska_stanica.Dolazak;

public interface OglasavanjeDolazaka {
	public void podesiKasnjenje(String mesto, int kasnjenje);
	public LinkedList<Dolazak> obrisiDolaske();
}
