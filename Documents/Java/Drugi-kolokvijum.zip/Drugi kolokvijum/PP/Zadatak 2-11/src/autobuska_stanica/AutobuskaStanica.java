package autobuska_stanica;

import java.util.LinkedList;
import java.util.GregorianCalendar;

import autobuska_stanica.dolasci.OglasavanjeDolazaka;

public class AutobuskaStanica implements OglasavanjeDolazaka {
	private Dolazak[] dolasci;

	public AutobuskaStanica() {
		dolasci = new Dolazak[50];
	}

	public void najaviDolazak(String mesto, GregorianCalendar vreme, int kasnjenje) {

		Dolazak dolazak = new Dolazak();
		dolazak.setMesto(mesto);
		dolazak.setVreme(vreme);
		dolazak.setKasnjenje(kasnjenje);

		for (int i = 0; i < dolasci.length; i++) {
			if (dolasci[i] == null) {
				dolasci[i] = dolazak;
				break;
			}

		}
	}

	@Override
	public void podesiKasnjenje(String mesto, int kasnjenje) {
		for(int i=0; i<dolasci.length; i++) {
			if (dolasci[i]==null) continue;
			
			if (dolasci[i].getMesto().equals(mesto)) {
				int novoVreme = dolasci[i].getKasnjenje()+kasnjenje;
				dolasci[i].setKasnjenje(novoVreme);
				System.out.println(dolasci[i]);
			}
		}
	}

	@Override
	public LinkedList<Dolazak> obrisiDolaske() {
		LinkedList<Dolazak> obrisaniDolasci = new LinkedList<Dolazak>();
		
		GregorianCalendar datum = new GregorianCalendar();
		datum.add(GregorianCalendar.DATE, -1); // jucerasnji datum
				
		for(int i=0; i<dolasci.length; i++) {
			GregorianCalendar vremeDolaska = dolasci[i].getVreme(); 

			if (vremeDolaska.equals(datum)) {
				obrisaniDolasci.add(dolasci[i]);
				dolasci[i] = null;
			}
		}
				
		return obrisaniDolasci;
	}

}
