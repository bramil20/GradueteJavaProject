package autobuska_stanica;

import java.util.GregorianCalendar;

public class Dolazak {
	String mesto;
	GregorianCalendar vreme;
	int kasnjenje;
	
	public String getMesto() {
		return mesto;
	}
	
	public void setMesto(String mesto) {
		if ((mesto==null) || (mesto.isEmpty())) {
			System.out.println("Greska: Mesto ne sme biti null ili prazan string!");
		} else {
			this.mesto = mesto;
		}				
	}
	
	public GregorianCalendar getVreme() {
		return vreme;
	}
	
	public void setVreme(GregorianCalendar vreme) {
		if (vreme == null) {
			System.out.println("Vreme ne sme biti null");
		} else {
			this.vreme = vreme;
		}
	}
	
	public int getKasnjenje() {
		return kasnjenje;
	}
	
	public void setKasnjenje(int kasnjenje) {
		if (kasnjenje < 0) {
			System.out.println("Greska: Kasnjene ne sme biti negativan broj!");
		} else {
			this.kasnjenje = kasnjenje;
		}
	}

	@Override
	public String toString() {
		if (kasnjenje > 0) {
			return "Mesto: " + mesto + " Vreme: " + vreme + " Kasnjenje:"
					+ kasnjenje + " minuta";
		}
		
		return "Mesto: " + mesto + " Vreme: " + vreme;
	}
	
	
	
	
	
}
