package hitna_pomoc;

import java.util.GregorianCalendar;

public class EkipaHitnePomoci {
	private String clanovi;
	private int brojIntervencija;
	private GregorianCalendar pocetakSmene;
	
	public String getClanovi() {
		return clanovi;
	}
	
	public void setClanovi(String clanovi) {
		if ((clanovi==null) || (clanovi.length()<30))
			System.out.println("Greska: clanovi ne sme biti null i krace od 30 znakova");
		else
			this.clanovi = clanovi;
	}
	
	public int getBrojIntervencija() {
		return brojIntervencija;
	}
	
	public void setBrojIntervencija(int brojIntervencija) {
		this.brojIntervencija = brojIntervencija;
	}
	
	public GregorianCalendar getPocetakSmene() {
		return pocetakSmene;
	}
	
	public void setPocetakSmene(GregorianCalendar pocetakSmene) {
		if ((pocetakSmene==null) || (!pocetakSmene.before(new GregorianCalendar())))
			System.out.println("Greska: pocetak smene ne sme biti null i mora biti trenutak u proslosti");
		else
			this.pocetakSmene = pocetakSmene;
	}

	@Override
	public String toString() {
		return "EkipaHitnePomoci [clanovi=" + clanovi + ", brojIntervencija="
				+ brojIntervencija + ", pocetakSmene=" + pocetakSmene + "]";
	}
	
}