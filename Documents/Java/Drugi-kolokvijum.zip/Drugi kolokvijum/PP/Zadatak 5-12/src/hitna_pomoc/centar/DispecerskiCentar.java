package hitna_pomoc.centar;

public interface DispecerskiCentar {
	public void smeniEkipe();
	public void primiPoziv();
}
