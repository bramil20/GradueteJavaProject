package hitna_pomoc;

import java.util.GregorianCalendar;

import hitna_pomoc.centar.DispecerskiCentar;

public class HitnaPomoc implements DispecerskiCentar {
	private EkipaHitnePomoci[] ekipe;
	
	public HitnaPomoc(int kapacitet) {
		if (kapacitet>0)
			ekipe = new EkipaHitnePomoci[kapacitet];
		else
			ekipe = new EkipaHitnePomoci[10];
	}
	
	
	@Override
	public void smeniEkipe() {
		for(int i=0; i<ekipe.length; i++) {
			if (ekipe[i]!=null) {
				if (ekipe[i].getBrojIntervencija()>20) ekipe[i]=null;
			}
		}		
	}
	
	public void unesiEkipu(String vozac, String medicinar1, String medicinar2) {
		EkipaHitnePomoci ekipa = new EkipaHitnePomoci();
		String clanovi="Vozac: "+vozac+" Medicinar1: "+medicinar1+" Medicinar2"+medicinar2;
		ekipa.setClanovi(clanovi);
		ekipa.setBrojIntervencija(0);
		ekipa.setPocetakSmene(new GregorianCalendar());
		
		boolean ubacen=false;
		for(int i=0; i<ekipe.length; i++){
			if (ekipe[i]==null) {
				ekipe[i]=ekipa;
				ubacen=true;
			}
		}
		
		if (!ubacen)
			System.out.println("Nema mesta u nizu!");				
	}

	@Override
	public void primiPoziv() {
		GregorianCalendar max=new GregorianCalendar();
		max.set(GregorianCalendar.YEAR, 1900);
		int maxPozicija=-1;
		
		for(int i=0; i<ekipe.length; i++) {
			if (ekipe[i]!=null) {
				if (ekipe[i].getPocetakSmene().after(max)) {
					max=ekipe[i].getPocetakSmene();
					maxPozicija=i;
				}
			}
		}
		
		int brojIntervencija = ekipe[maxPozicija].getBrojIntervencija()+1;
		ekipe[maxPozicija].setBrojIntervencija(brojIntervencija+1);		
	}

}
