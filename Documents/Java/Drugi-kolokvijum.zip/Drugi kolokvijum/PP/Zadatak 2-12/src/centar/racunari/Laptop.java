package centar.racunari;

public class Laptop extends Racunar {
	private String model;
	
	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	@Override
	public void ispisi() {
		System.out.println("Konfigurcija: "+getKonfiguracija() + " Model: "+ getModel() +" Vreme nabavke: "+getVremeNabavke());
	}

}
