package centar;

import java.util.GregorianCalendar;

import centar.racunari.Desktop;
import centar.racunari.Laptop;
import centar.racunari.Racunar;

public class RacunarskiCentar {
	private Racunar[] racunari=new Racunar[50];
	
	public void prikaziKupljeneTekuceGodine() {
		int tekucaGodina = (new GregorianCalendar()).get(GregorianCalendar.YEAR);
		
		for(int i=0; i<racunari.length; i++) {
			if ((racunari[i]!=null) && 
				(racunari[i].getVremeNabavke().get(GregorianCalendar.YEAR) == tekucaGodina)) {
				System.out.println("Konfiguracija: "+racunari[i].getKonfiguracija() +" Vreme nabavke: "+ racunari[i].getVremeNabavke());
			}	
		}
	}

	public void unesiRacunar(String konfiguracja, GregorianCalendar vremeNabavke, String model) {
		if (model!=null) {
			Laptop laptop = new Laptop();
			laptop.setKonfiguracija(konfiguracja);
			laptop.setVremeNabavke(vremeNabavke);
			laptop.setModel(model);
			
			for(int i=0; i<racunari.length; i++)
				if (racunari[i]==null) racunari[i]=laptop;
			
		} else {			
			Desktop desktop = new Desktop();
			desktop.setKonfiguracija(konfiguracja);
			desktop.setVremeNabavke(vremeNabavke);
			
			for(int i=0; i<racunari.length; i++)
				if (racunari[i]==null) racunari[i]=desktop;						
		}					
	}

	public void obrniRedosled() {
		int brojElemenata=racunari.length; 
		for(int i=0; i<brojElemenata/2; i++) {
			Racunar r = racunari[i];
			racunari[i]=racunari[brojElemenata-1-i];
			racunari[brojElemenata-1-i]=r;			
		}
	}
	
	
}
