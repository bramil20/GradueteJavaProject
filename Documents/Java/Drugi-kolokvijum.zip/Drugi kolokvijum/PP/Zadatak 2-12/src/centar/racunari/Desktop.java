package centar.racunari;

public class Desktop extends Racunar {

	@Override
	public void ispisi() {
		System.out.println("Konfigurcija: "+getKonfiguracija() + " Vreme nabavke: "+getVremeNabavke());
	}

}
