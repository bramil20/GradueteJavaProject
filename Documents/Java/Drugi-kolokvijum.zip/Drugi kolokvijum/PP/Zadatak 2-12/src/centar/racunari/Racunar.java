package centar.racunari;

import java.util.GregorianCalendar;

public abstract class Racunar {
	private String konfiguracija;
	private GregorianCalendar vremeNabavke;
	
	public String getKonfiguracija() {
		return konfiguracija;
	}
	
	public void setKonfiguracija(String konfiguracija) {
		if ((konfiguracija==null) || (konfiguracija.length()<10)) 
			System.out.println("Greska: Konfiguracija ne sme biti null i string kraci od 10 znakova");
		else
			this.konfiguracija = konfiguracija;
	}
	
	public GregorianCalendar getVremeNabavke() {
		return vremeNabavke;
	}
	
	public void setVremeNabavke(GregorianCalendar vremeNabavke) {
		if ((vremeNabavke==null) || (!vremeNabavke.before(new GregorianCalendar())))
			System.out.println("Greska: Vreme ne sme biti null i mora biti trenutak iz proslosti");
		else
			this.vremeNabavke = vremeNabavke;
	}
	
	public abstract void ispisi();
	
}
