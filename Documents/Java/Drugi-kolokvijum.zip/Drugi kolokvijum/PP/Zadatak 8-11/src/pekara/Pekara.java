package pekara;

import java.util.GregorianCalendar;
import java.util.LinkedList;
import namirnice.Pecivo;

public class Pekara {

		private GregorianCalendar poslednjaTura;
		private Pecivo[] ponudaPeciva;
		
		public Pekara(int brojVrstaPeciva) {
			if (brojVrstaPeciva>0) {
				ponudaPeciva = new Pecivo[brojVrstaPeciva];
			} else {
				ponudaPeciva = new Pecivo[15];
				System.out.println("Greska: Kapacitet niza mora biti veci od nule!");
			}
		}
		
		public double najjeftinijePecivo() {
			double minCena = ponudaPeciva[0].getCena();
			for(int i=1; i<ponudaPeciva.length; i++) {
				if (ponudaPeciva[i] != null){
					if (ponudaPeciva[i].getCena() < minCena) 
						minCena = ponudaPeciva[i].getCena(); 
				}
			}
			return minCena;
		}
		
		public void unesiPecivo(String nazivPeciva, double cena, boolean jePosno) {
			Pecivo pecivo = new Pecivo();
			pecivo.setNazivNamirnice(nazivPeciva);
			pecivo.setCena(cena);
			pecivo.setJePosna(jePosno);
			
			
			for(int i=0; i<ponudaPeciva.length; i++) 
				if (ponudaPeciva[i].equals(pecivo)) { 
					System.out.println("Greska: Pecivo se vec nalazi u ponudi");
					return;
				}
			
			
			for(int i=0; i<ponudaPeciva.length; i++) {
				if (ponudaPeciva[i]==null) {
					ponudaPeciva[i]=pecivo;
					poslednjaTura = new GregorianCalendar();
					break;
				}
			}								
		}
		
		public LinkedList<Pecivo> triNajskupljaPeciva() {
			LinkedList<Pecivo> najskupljaPosnaPeciva = new LinkedList<Pecivo>();

			//Uvodimo pomocne promenljive za sva tri najskuplja peciva, kao i
			//pomocne promenljive za pozicije prva dva maksimuma
			Pecivo max1 = null;
			int max1Pozicija = -1;
			Pecivo max2 = null;
			int max2Pozicija = -1;
			Pecivo max3 = null;
			
			//Prvo trazimo max1 tj. najskuplje pecivo i njegovu poziciju tj. indeks u nizu
			for (int i=0 ; i < ponudaPeciva.length; i++) 
				if (ponudaPeciva!=null && ponudaPeciva[i].jePosna() &&
					(max1==null || ponudaPeciva[i].getCena() > max1.getCena())){
						max1 = ponudaPeciva[i];
						max1Pozicija = i;
					}
			
			//Onda trazimo max2 tj. drugo najskuplje pecivo i njegovu poziciju tj. indeks u nizu
			//Pazimo na to da preskocimo max1 koji smo vec nasli i to tako sto preskacemo onaj
			//element niza sa indeksom max1Pozicija
			for (int i=0 ; i < ponudaPeciva.length; i++) 
				if (i!=max1Pozicija && ponudaPeciva!=null && ponudaPeciva[i].jePosna() &&
					(max2==null || ponudaPeciva[i].getCena() > max2.getCena())){
						max2 = ponudaPeciva[i];
						max2Pozicija = i;
					}
			
			//Na kraju trazimo max3 tj. trece najskuplje pecivo i njegovu poziciju tj. indeks u nizu
			//Pazimo na to da preskocimo max1 i max2 koje smo vec nasli i to tako sto preskacemo onaj
			//elemente niza sa indeksima max1Pozicija i max2Pozicija
			for (int i=0 ; i < ponudaPeciva.length; i++) 
				if (i!=max1Pozicija && i!=max2Pozicija
					&& ponudaPeciva!=null && ponudaPeciva[i].jePosna() &&
					(max3==null || ponudaPeciva[i].getCena() > max3.getCena())){
						max3 = ponudaPeciva[i];
					}	
			
			//Na kraju dodajemo sva tri najskuplja peciva u listu i to na prvu poziciju max1,
			//pa za njim max2, a na kraj max3
			najskupljaPosnaPeciva.addFirst(max1);
			najskupljaPosnaPeciva.addLast(max2);
			najskupljaPosnaPeciva.addLast(max3);
			

			return najskupljaPosnaPeciva;			
		}
		
		
}
