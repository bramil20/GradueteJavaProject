package namirnice;

public class Pecivo extends Namirnica {
	@Override
	public void prikazi() {
		System.out.println("Naziv peciva: "+getNazivNamirnice()+" Posna: "+jePosna()+" Cena: "+getCena());	
	}
}
