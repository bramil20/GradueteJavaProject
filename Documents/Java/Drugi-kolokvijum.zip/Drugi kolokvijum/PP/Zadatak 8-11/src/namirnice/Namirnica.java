package namirnice;

public abstract class Namirnica {
	private String nazivNamirnice;
	private boolean jePosna;
	private double cena=0;
	
	public String getNazivNamirnice() {
		return nazivNamirnice;
	}
	
	public void setNazivNamirnice(String nazivNamirnice) {
		if ((nazivNamirnice == null) || (nazivNamirnice.isEmpty()))
			System.out.println("Greska: Naziv namirnice ne sme biti null ili prazan string!");
		else
			this.nazivNamirnice = nazivNamirnice;
	}
	
	public boolean jePosna() {
		return jePosna;
	}
	
	public void setJePosna(boolean jePosna) {
		this.jePosna = jePosna;
	}
	
	public double getCena() {
		return cena;
	}
	
	public void setCena(double cena) {
		if (cena<=0)
			System.out.println("Greska: Cena mora biti veca od nule!");
		else
			this.cena = cena;
	}

	@Override
	public boolean equals(Object obj) {
		Namirnica namirnica = (Namirnica) obj;

		if ((nazivNamirnice.equals(namirnica.nazivNamirnice)) &&
			(jePosna == namirnica.jePosna) &&
			(cena == namirnica.cena)) {
			return true;
		}
		return false;		
	}
	
	
	public abstract void prikazi();
	
}
