package izlozba;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import eksponati.Eksponat;
import eksponati.slike.Slika;

public class Izlozba {
	private GregorianCalendar datumOtvaranja;
	private Eksponat[] eksponati;
	
	public Izlozba(GregorianCalendar datumOtvaranja) {
		this.datumOtvaranja = datumOtvaranja;
		eksponati = new Eksponat[50];
	}
	
	public void unesiEksponat(Eksponat eksponat) {		
		if (eksponat == null) {
			System.out.println("Greska: Eksponat ne sme biti null!");
			return;
		}
		
		boolean unet = false;
		for(int i=0; i<eksponati.length; i++) {
			if (eksponati[i]==null) {
				eksponati[i]=eksponat;
				unet=true;
				break;
			}
		}
		
		if (!unet)
			System.out.println("Greska: Nema mesta u nizu za unos eksponata!");
		
		
	}
	
	public void ispisiSveEksponate(String autor) {
		System.out.println("Datum otvaranja izlozbe: "+datumOtvaranja);
		System.out.println("Eksponati:");
		
		for(int i=0; i<eksponati.length; i++) {
			if (eksponati[i].getAutor().equals(autor)) {
				eksponati[i].ispisi();
			}
		}
	}
	
	public LinkedList<Slika> pronadjiSlike(String prezime) {
		LinkedList<Slika> slike = new LinkedList<Slika>();
		
		for(int i=0; i<eksponati.length; i++) {
			if (!(eksponati[i] instanceof Slika)) continue;
			
			Slika slika = (Slika)eksponati[i];
			
			if ((slika.getTehnika().equals("tempera")) && (slika.getAutor().endsWith(prezime))) {
				slike.add(slika);
			}
		}
		
		return slike;
	}
	
}
