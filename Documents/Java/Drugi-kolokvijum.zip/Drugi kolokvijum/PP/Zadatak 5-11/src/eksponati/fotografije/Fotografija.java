package eksponati.fotografije;

import eksponati.Eksponat;

public class Fotografija extends Eksponat {

	@Override
	public void ispisi() {
		System.out.println("Naziv: "+getNaziv()+" Autor: "+getAutor()+ " Eksponat je fotografija");
	}

}
