package eksponati.skulpture;

import eksponati.Eksponat;

public class Skulptura extends Eksponat {
	private String materijal;

	public String getMaterijal() {
		return materijal;
	}

	public void setMaterijal(String materijal) {
		this.materijal = materijal;
	}

	@Override
	public void ispisi() {
		System.out.println("Naziv: "+getNaziv()+" Autor:"+getAutor()+" Materijal "+materijal+" Eksponat je skulptura "+getCena());
	}
	
}
