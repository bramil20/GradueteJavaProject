package eksponati.slike;

import eksponati.Eksponat;

public class Slika extends Eksponat {
	@Override
	public void ispisi() {
		System.out.println("Naziv: "+getNaziv()+" Autor:"+getAutor()+" Eksponat je slika");		
	}
}
