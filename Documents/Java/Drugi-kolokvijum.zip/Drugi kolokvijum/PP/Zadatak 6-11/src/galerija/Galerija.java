package galerija;

import java.util.GregorianCalendar;

import eksponati.Eksponat;
import eksponati.skulpture.Skulptura;

public class Galerija {
	private Eksponat[] eksponati;

	public Galerija() {
		eksponati = new Eksponat[100];
	}

	public void unesiEksponat(Eksponat eksponat) {
		if (eksponat == null) {
			System.out.println("Greska: Eksponat ne sme biti null!");
			return;
		}

		boolean unet = false;
		for (int i = 0; i < eksponati.length; i++) {
			if (eksponati[i] == null) {
				eksponati[i] = eksponat;
				// eksponati[i].setDatumPrijema(new GregorianCalendar());
				unet = true;
				break;
			}
		}

		if (!unet)
			System.out.println("Greska: Nema mesta u nizu za unos eksponata!");
	}

	public void uvediPopust(double popust) {
		GregorianCalendar danas = new GregorianCalendar();
		int prethodnaGodina = danas.get(GregorianCalendar.YEAR) - 1;

		for (int i = 0; i < eksponati.length; i++) {
			if (eksponati[i].getDatumPrijema().get(GregorianCalendar.YEAR) == prethodnaGodina) {
				double novaCena = eksponati[i].getCena()
						* ((100 - popust) / 100);
				eksponati[i].setCena(novaCena);
			}
		}
	}

	public Skulptura[] najskupljeOdBronze() {
		Skulptura[] najskuplji = new Skulptura[2];

		for (int i = 0; i < eksponati.length; i++) {
			if (eksponati[i] != null && eksponati[i] instanceof Skulptura) {

				Skulptura skulptura = (Skulptura) eksponati[i];

				if (skulptura.getMaterijal().equals("bronza")) {

					if (najskuplji[0] == null
							|| skulptura.getCena() > najskuplji[0].getCena()) {
						najskuplji[1] = najskuplji[0];
						najskuplji[0] = skulptura;
					} else if (najskuplji[1] == null
							|| skulptura.getCena() > najskuplji[1].getCena()) {
						najskuplji[1] = skulptura;
					}

				}

			}
		}

		return najskuplji;
	}

}
