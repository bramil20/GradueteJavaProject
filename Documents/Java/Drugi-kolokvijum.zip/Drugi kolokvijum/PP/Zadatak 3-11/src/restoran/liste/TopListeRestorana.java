package restoran.liste;

import restoran.Restoran;

public interface TopListeRestorana {
	public void napraviTopListu(String vrstaKuhinje, int godina);
	public Restoran[] napraviTopListu(String vrstaKuhinje);
}
