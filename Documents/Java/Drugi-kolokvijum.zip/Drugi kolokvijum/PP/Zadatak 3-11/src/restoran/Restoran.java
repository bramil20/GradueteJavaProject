package restoran;

import java.util.GregorianCalendar;

public class Restoran {
	private String naziv;
	private String vrstaKuhinje;
	private int ocena;
	private GregorianCalendar datumProcene;
	
	public String getNaziv() {
		return naziv;
	}
	
	public void setNaziv(String naziv) {
		if ((naziv == null) || (naziv.isEmpty())) {
			System.out.println("Greska: Naziv ne sme biti null ili prazan string!");
		} else {
			this.naziv = naziv;
		}
	}
	
	public String getVrstaKuhinje() {
		return vrstaKuhinje;
	}
	
	public void setVrstaKuhinje(String vrstaKuhinje) {
		if ((vrstaKuhinje == null) || (vrstaKuhinje.isEmpty())) {
			System.out.println("Greska: Naziv ne sme biti null ili prazan string!");
		} else {
			this.vrstaKuhinje = vrstaKuhinje;
		}				
	}
	
	public int getOcena() {
		return ocena;
	}
	
	public void setOcena(int ocena) {
		if ((ocena<1) || (ocena>5)) {
			System.out.println("Greska: Ocena mora biti izmedju 1 i 5");
		} else {
			this.ocena = ocena;
		}
	}
	
	public GregorianCalendar getDatumProcene() {
		return datumProcene;
	}
	
	public void setDatumProcene(GregorianCalendar datumProcene) {
		if (datumProcene == null) {
			System.out.println("Greska: Datum procene ne sme biti null!");
		} else {
			this.datumProcene = datumProcene;
		}
	}

	@Override
	public String toString() {
		return "Restoran [naziv=" + naziv + ", vrstaKuhinje=" + vrstaKuhinje
				+ ", ocena=" + ocena + ", datumProcene=" + datumProcene + "]";
	}
	
	
	
	
}
