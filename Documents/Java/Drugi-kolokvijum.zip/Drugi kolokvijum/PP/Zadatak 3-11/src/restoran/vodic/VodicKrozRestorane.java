package restoran.vodic;

import java.util.GregorianCalendar;
import java.util.LinkedList;
import restoran.Restoran;
import restoran.liste.TopListeRestorana;

public class VodicKrozRestorane implements TopListeRestorana {
	LinkedList<Restoran> restorani = new LinkedList<Restoran>();

	public void unesiRestoran(Restoran restoran) {
		if (restoran == null) {
			System.out.println("Greska: Restoran ne sme biti null!");
			return;
		}

		restorani.addFirst(restoran);
	}

	@Override
	public void napraviTopListu(String vrstaKuhinje, int godina) {
		for (int i = 0; i < restorani.size(); i++) {
			Restoran restoran = restorani.get(i);
			if (restoran.getVrstaKuhinje().equals(vrstaKuhinje)
					&& (restoran.getOcena() == 5)
					&& restoran.getDatumProcene().get(GregorianCalendar.YEAR) == godina) {
				System.out.println(restoran);
			}
		}

	}

	@Override
	public Restoran[] napraviTopListu(String vrstaKuhinje) {
		Restoran[] topLista = new Restoran[10];

		int ocena = 5;
		int brojRestorana = 0;
		while (ocena > 3) {

			for (int i = 0; i < restorani.size(); i++) {
				Restoran restoran = restorani.get(i);
				if (restoran.getOcena() == ocena) {
					topLista[brojRestorana] = restoran;
					brojRestorana++;
				}
				
				if (brojRestorana == 10) {
					return topLista;
				}
			}
			ocena--;
		}
		
		while (brojRestorana<10) {
			topLista[brojRestorana] = null;
			brojRestorana++;
		}
		
		
		return topLista;
		
	}

}
