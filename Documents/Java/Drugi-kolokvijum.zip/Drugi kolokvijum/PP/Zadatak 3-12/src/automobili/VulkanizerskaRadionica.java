package automobili;

import java.util.GregorianCalendar;
import java.util.LinkedList;

import automobili.gume.Guma;
import automobili.gume.pretrazivac.PretrazivacGuma;

public class VulkanizerskaRadionica implements PretrazivacGuma {
	LinkedList<Guma> gume = new LinkedList<Guma>();
			
	@Override
	public void prikaziPonudu(int sirina, int visina, int precnik,
			boolean jeZimska) {
		for(int i=0; i<gume.size(); i++) {
			Guma guma = gume.get(i);
			String dimenzije=sirina+"/"+visina+"/"+precnik;
			if (guma.getDimenzije().equals(dimenzije))
				System.out.println(guma);			
		}
		
	}

	@Override
	public void unesiGumu(Guma guma) {
		if ((guma!=null) && (guma.getDatumProizvodnje().before(new GregorianCalendar())))
			gume.addFirst(guma);
		else 
			System.out.println("Guma je null ili datum proizvodnje nije u proslosti");
	}
	
	public void obrniRedosled() {
		int brojElemenata=gume.size(); 
		for(int i=0; i<brojElemenata/2; i++) {
			Guma g1 = gume.get(i);
			Guma g2 = gume.get(brojElemenata-1-i);
			gume.set(i, g2);
			gume.set(brojElemenata-1-i, g1);
		}		
	}	
	
	
}
