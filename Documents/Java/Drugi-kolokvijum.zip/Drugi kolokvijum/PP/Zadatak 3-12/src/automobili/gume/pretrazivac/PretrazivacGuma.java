package automobili.gume.pretrazivac;

import automobili.gume.Guma;

public interface PretrazivacGuma {
	public void prikaziPonudu(int sirina, int visina, int precnik, boolean jeZimska);
	public void unesiGumu(Guma guma);
}
