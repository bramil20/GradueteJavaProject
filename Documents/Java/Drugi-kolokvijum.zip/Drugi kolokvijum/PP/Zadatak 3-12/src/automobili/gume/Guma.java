package automobili.gume;

import java.util.GregorianCalendar;

public class Guma {
	private String marka; // u tekstu stoji naziv u delu o geterima i seterima
	private String dimenzije;
	private String zimska;
	private GregorianCalendar datumProizvodnje;
	
	public String getMarka() {
		return marka;
	}
	
	public void setMarka(String marka) {
		if ((marka==null) || (marka.isEmpty()))
			System.out.println("Greska: Naziv ne sme biti null ili prazan string");
		else
			this.marka = marka;
	}
	
	public String getDimenzije() {
		return dimenzije;
	}
	
	public void setDimenzije(String dimenzije) {
		if ((dimenzije==null) || (dimenzije.length()!=9))
			System.out.println("Greska: Dimenzije ne smeju biti null ili duzine razlicite od 9 znakova");
		else
			this.dimenzije = dimenzije;
	}
	
	public String getZimska() {
		return zimska;
	}
	
	public void setZimska(String zimska) {
		this.zimska = zimska;
	}
	
	public GregorianCalendar getDatumProizvodnje() {
		return datumProizvodnje;
	}
	
	public void setDatumProizvodnje(GregorianCalendar datumProizvodnje) {
		if (datumProizvodnje==null)
			System.out.println("Greska: Datum proizvodnje ne sme biti null");
		else
			this.datumProizvodnje = datumProizvodnje;
	}

	@Override
	public String toString() {
		return "Guma [marka=" + marka + ", dimenzije=" + dimenzije
				+ ", zimska=" + zimska + ", datumProizvodnje="
				+ datumProizvodnje + "]";
	}
	
	
	
	
	
	
}
