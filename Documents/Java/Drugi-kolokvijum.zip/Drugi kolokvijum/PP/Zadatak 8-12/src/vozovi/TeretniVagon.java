package vozovi;

public class TeretniVagon extends Vagon {
	private int maxNosivost;

	public int getMaxNosivost() {
		return maxNosivost;
	}

	public void setMaxNosivost(int maxNosivost) {
		if (maxNosivost<=0)
			System.out.println("Greska: Nosivost mora biti veca od nule");
		else 
			this.maxNosivost = maxNosivost;
	}

	@Override
	public void ispisi() {
		System.out.println("Vagon je teretni, max nosivost: "+maxNosivost);
	}

}
