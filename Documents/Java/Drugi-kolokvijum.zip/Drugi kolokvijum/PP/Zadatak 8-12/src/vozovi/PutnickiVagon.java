package vozovi;

public class PutnickiVagon extends Vagon {
	private int maxBrojPutnika;

	public int getMaxBrojPutnika() {
		return maxBrojPutnika;
	}

	public void setMaxBrojPutnika(int maxBrojPutnika) {
		if ((maxBrojPutnika<=0) || (maxBrojPutnika>50))
			System.out.println("Greska: max broj putnika mora biti veci od nule i manji od 50");
		else 
			this.maxBrojPutnika = maxBrojPutnika;
	}

	@Override
	public void ispisi() {
		System.out.println("Vagon je putnicki, max broj putnika "+maxBrojPutnika);
	}
		
}
