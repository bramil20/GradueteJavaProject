package vozovi;

public abstract class Vagon {
	public abstract void ispisi();
}
