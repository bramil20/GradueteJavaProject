package vozovi.kompozicija;

import java.util.LinkedList;

import vozovi.PutnickiVagon;
import vozovi.TeretniVagon;
import vozovi.Vagon;

public class Kompozicija {
	private LinkedList<Vagon> vagoni=new LinkedList<Vagon>();
	
	public void unesiVagon(Vagon vagon) {
		vagoni.addLast(vagon);
		for(int i=vagoni.size()-1; i>0; i--) {
			vagoni.get(i).ispisi();
		}
	}
	
	public void ispisiKompoziciju() {
		for(int i=0; i<vagoni.size(); i++) {
			if (vagoni.get(i) instanceof TeretniVagon)
				vagoni.get(i).ispisi();
		}

		for(int i=0; i<vagoni.size(); i++) {
			if (vagoni.get(i) instanceof PutnickiVagon)
				vagoni.get(i).ispisi();
		}						
	}
	
	public void proveri(int brojPutnika, int teret) {
		int maxPutnika=0;
		int maxTeret=0;
		
		for(int i=0; i<vagoni.size(); i++) {
			if (vagoni.get(i) instanceof TeretniVagon) {
				TeretniVagon tv=(TeretniVagon)vagoni.get(i);
				maxTeret=maxTeret+tv.getMaxNosivost();
			} else {
				PutnickiVagon pv=(PutnickiVagon)vagoni.get(i);
				maxPutnika=maxPutnika+pv.getMaxBrojPutnika();
			}
		}
		
		if ((brojPutnika<=maxPutnika) && (teret<=maxTeret)) {
			System.out.println("Vagoni mogu da prime dati broj putnika i teret");
		} else {
			System.out.println("Vagoni ne mogu da prime dati broj putnika i teret");
		}
			
		
	}
	
	
}
